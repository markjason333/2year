import { useState } from 'react';
import HeroSection from './components/HeroSection';
import ProfileCard from './components/ProfileCard';
import Navigation from './components/Navigation';
import PhysicalPlan from './components/PhysicalPlan';
import DietPlan from './components/DietPlan';
import MentalPlan from './components/MentalPlan';
import MedicalPlan from './components/MedicalPlan';
import HairPlan from './components/HairPlan';
import VoicePlan from './components/VoicePlan';
import PosturePlan from './components/PosturePlan';
import RoadmapPlan from './components/RoadmapPlan';
import Footer from './components/Footer';

function App() {
  const [activeSection, setActiveSection] = useState('physical');

  return (
    <div className="min-h-screen bg-gray-950 text-white font-sans">
      <HeroSection />
      <ProfileCard />
      <Navigation activeSection={activeSection} setActiveSection={setActiveSection} />
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeSection === 'physical' && <PhysicalPlan />}
        {activeSection === 'diet' && <DietPlan />}
        {activeSection === 'mental' && <MentalPlan />}
        {activeSection === 'medical' && <MedicalPlan />}
        {activeSection === 'hair' && <HairPlan />}
        {activeSection === 'voice' && <VoicePlan />}
        {activeSection === 'posture' && <PosturePlan />}
        {activeSection === 'roadmap' && <RoadmapPlan />}
      </main>
      <Footer />
    </div>
  );
}

export default App;
