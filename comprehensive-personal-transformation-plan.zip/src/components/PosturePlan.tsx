function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function PosturePlan() {
  const neckExercises = [
    {
      name: 'Chin Tucks',
      sets: '3×15 reps',
      how: 'Sit tall. Pull chin straight back (like making a double chin). Hold 2 sec. Release. MOST important exercise for forward head posture.',
      targets: 'Deep cervical flexors, forward head correction',
    },
    {
      name: 'Neck Half-Circles',
      sets: '3×10 each direction',
      how: 'Slowly drop ear to shoulder. Roll chin down to chest. Rise to other side. NEVER go to full back extension (can damage cervical discs).',
      targets: 'Neck mobility, muscle release',
    },
    {
      name: 'Levator Scapulae Stretch',
      sets: '3×30 sec each side',
      how: 'Tilt head to side and rotate chin toward armpit. Place hand on back of head for gentle pressure. Hold. This is the MAIN tight muscle in neck pain.',
      targets: 'Neck pain at shoulder junction',
    },
    {
      name: 'Neck Isometric Holds',
      sets: '3×10 sec each direction',
      how: 'Place hand against your forehead. Try to push head forward but RESIST with hand — create tension without movement. Do all 4 directions (front, back, left, right).',
      targets: 'Neck muscle strengthening',
    },
    {
      name: 'Thoracic Extension (Chair)',
      sets: '3×10 reps',
      how: 'Sit at chair edge. Place hands behind head. Extend back OVER the chair top, opening chest toward ceiling. Pause 2 seconds. This reverses hours of forward slouching.',
      targets: 'Upper back extension, neck relief',
    },
  ];

  const pelvicExercises = [
    {
      name: 'Glute Bridges',
      sets: '4×20 reps',
      how: 'Lie on back, knees bent. Drive hips to ceiling by SQUEEZING glutes — not pushing with hamstrings. Hold 2 sec at top. STRONGEST exercise for pelvic tilt correction.',
      targets: 'Glutes (inhibited), lower back stabilization',
    },
    {
      name: 'Dead Bug',
      sets: '3×10 each side',
      how: 'Lie on back. Arms up, knees at 90°. Slowly lower one arm and opposite leg toward floor. Return. BACK MUST STAY FLAT. This trains deep core anti-extension.',
      targets: 'Deep core, transverse abdominis',
    },
    {
      name: 'Hip Flexor Stretch (Kneeling Lunge)',
      sets: '3×45 sec each side',
      how: 'Kneel on one knee (padded). Push hips FORWARD gently. Feel stretch in front of hip of kneeling leg. For more, raise same-side arm overhead and lean away.',
      targets: 'Tight hip flexors — primary pelvic tilt cause',
    },
    {
      name: 'Seated Hamstring Stretch',
      sets: '3×30 sec each side',
      how: 'Sit on chair edge. Extend one leg. Hinge forward from hips (NOT spine) until you feel hamstring stretch. Tight hamstrings pull pelvis into posterior tilt.',
      targets: 'Hamstrings (if posterior tilt)',
    },
    {
      name: 'Cat-Cow Spinal Waves',
      sets: '3×15 cycles',
      how: 'On hands and knees. Inhale: arch back, lift head and tailbone (cow). Exhale: round back, tuck chin and pelvis (cat). Slow and controlled. 2 seconds each position.',
      targets: 'Spinal mobility, pelvic control',
    },
    {
      name: 'Pelvic Tilts (Standing)',
      sets: '3×20 reps',
      how: 'Stand against wall. Squeeze glutes and draw abs in to flatten lower back against wall. Hold 5 sec. Release. This teaches neutral pelvis awareness.',
      targets: 'Pelvic neutral position retraining',
    },
    {
      name: 'Bird Dog',
      sets: '3×12 each side',
      how: 'On hands and knees. Extend opposite arm and leg simultaneously. Hold 3 sec. Keep hips perfectly square — do not rotate. Return slowly.',
      targets: 'Erector spinae, glutes, coordination',
    },
    {
      name: 'Plank (Posterior Pelvic Tilt)',
      sets: '3×30–60 sec',
      how: 'Standard plank but focus on TUCKING pelvis — actively squeezing glutes and pulling belly button toward spine. This is the correct pelvic position.',
      targets: 'Core, correct plank mechanics',
    },
  ];

  const deskErgonomics = [
    { item: 'Chair Height', fix: 'Feet flat on floor. Knees at 90°. Hips slightly above knee level. Use cushion if needed.' },
    { item: 'Monitor Height', fix: 'Top of screen at eye level. Distance: arm\'s length. Prevents forward head posture.' },
    { item: 'Lower Back Support', fix: 'Use lumbar roll or rolled towel at lower back natural curve. Do not slouch.' },
    { item: 'Keyboard Position', fix: 'Keyboard at elbow height. Arms relaxed. Shoulders NOT raised or hunched.' },
    { item: 'Phone Usage', fix: 'Never hold phone between neck and shoulder. Use headset or speaker. This is a major neck pain cause.' },
    { item: 'Hourly Breaks', fix: 'Set alarm every 45 mins. Stand up. Do 10 squats + neck rolls + chest opener. Non-negotiable.' },
  ];

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🧍</span>
          <h2 className="text-3xl font-black text-white">Posture & Pain Correction Plan</h2>
        </div>
        <p className="text-gray-400 ml-14">Fix neck pain, pelvic tilt, and stand like a warrior — specific exercises for your sedentary job</p>
      </div>

      {/* Root Cause */}
      <Card className="border-red-500/30 bg-red-900/10">
        <h3 className="text-lg font-bold text-red-400 mb-3">🔬 What's Causing Your Problems</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h4 className="text-white font-semibold mb-3">Neck Pain Causes:</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              {[
                'Forward Head Posture (8 hrs/day at screen)',
                'Tight Levator Scapulae & Upper Traps',
                'Weak Deep Cervical Flexors',
                'Poor monitor height',
                'Stress tension accumulation',
              ].map((c) => <li key={c} className="flex gap-2"><span className="text-red-400">→</span>{c}</li>)}
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">Pelvic Tilt Causes (Anterior):</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              {[
                'Tight Hip Flexors (8+ hrs sitting)',
                'Weak Glutes (not activated)',
                'Tight Lower Back (Erectors)',
                'Weak Core (Deep Abs)',
                'Prolonged chair sitting',
              ].map((c) => <li key={c} className="flex gap-2"><span className="text-red-400">→</span>{c}</li>)}
            </ul>
          </div>
        </div>
        <div className="mt-4 bg-gray-700/30 rounded-xl p-3">
          <p className="text-gray-300 text-sm">
            <strong className="text-white">Good news:</strong> Both neck pain and pelvic tilt are <strong className="text-green-400">100% reversible</strong> with consistent corrective exercise. Your calisthenics program also directly addresses these — pull-ups, dead hangs, and glute bridges are the cure.
          </p>
        </div>
      </Card>

      {/* Neck Protocol */}
      <Card className="border-blue-500/30">
        <h3 className="text-xl font-bold text-blue-400 mb-2">🦴 Neck Pain Correction Protocol</h3>
        <p className="text-gray-400 text-sm mb-5">Do this routine: Morning (5 min) + Every 2 hours at desk (2 min)</p>
        <div className="grid md:grid-cols-2 gap-4">
          {neckExercises.map((ex) => (
            <div key={ex.name} className="bg-gray-700/30 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-white font-bold text-sm">{ex.name}</h4>
                <span className="text-blue-400 text-xs bg-blue-500/10 px-2 py-1 rounded-lg">{ex.sets}</span>
              </div>
              <p className="text-gray-400 text-xs mb-2 leading-relaxed">{ex.how}</p>
              <div className="text-blue-300 text-xs bg-blue-900/20 rounded-lg px-3 py-1">
                Targets: {ex.targets}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Pelvic Tilt Protocol */}
      <Card className="border-purple-500/30">
        <h3 className="text-xl font-bold text-purple-400 mb-2">🦵 Pelvic Tilt Correction Protocol</h3>
        <p className="text-gray-400 text-sm mb-5">Do this routine: Daily, 20–25 minutes. Can be split — morning stretch routine + evening strength routine.</p>
        <div className="grid md:grid-cols-2 gap-4">
          {pelvicExercises.map((ex) => (
            <div key={ex.name} className="bg-gray-700/30 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-white font-bold text-sm">{ex.name}</h4>
                <span className="text-purple-400 text-xs bg-purple-500/10 px-2 py-1 rounded-lg">{ex.sets}</span>
              </div>
              <p className="text-gray-400 text-xs mb-2 leading-relaxed">{ex.how}</p>
              <div className="text-purple-300 text-xs bg-purple-900/20 rounded-lg px-3 py-1">
                Targets: {ex.targets}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Desk Ergonomics */}
      <Card className="border-green-500/30">
        <h3 className="text-xl font-bold text-green-400 mb-4">🪑 Workstation Ergonomics — Fix Your Desk Setup</h3>
        <div className="space-y-3">
          {deskErgonomics.map((item) => (
            <div key={item.item} className="bg-gray-700/30 rounded-xl p-4 flex items-start gap-4">
              <div className="w-32 flex-shrink-0">
                <span className="text-white font-bold text-sm">{item.item}</span>
              </div>
              <div className="text-gray-300 text-sm">{item.fix}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Standing Rules */}
      <Card className="border-orange-500/30">
        <h3 className="text-xl font-bold text-orange-400 mb-4">⚡ Immediate Posture Fixes — Do NOW</h3>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            {
              title: 'The Military Stand',
              desc: 'Feet shoulder-width. Knees slightly bent. Glutes squeezed. Belly tucked. Chest out. Shoulders rolled back and down. Chin parallel to floor. This IS confident posture.',
              icon: '🪖',
            },
            {
              title: 'The Walk',
              desc: 'Eyes forward, NOT down. Shoulders back. Arms swing naturally. Take longer strides. Move with intention — like you own the floor. This signals dominance to everyone including your own brain.',
              icon: '🚶',
            },
            {
              title: 'The Sit',
              desc: 'Sit tall, NOT forward. Feel your sit bones — weight equal on both. Lower back has natural arch. No crossing of legs. Both feet flat. Check every 15 minutes.',
              icon: '💺',
            },
          ].map((item) => (
            <div key={item.title} className="bg-gray-700/30 rounded-xl p-4">
              <div className="text-3xl mb-2">{item.icon}</div>
              <h4 className="text-white font-bold mb-2">{item.title}</h4>
              <p className="text-gray-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Progress Timeline */}
      <Card className="border-yellow-500/30">
        <h3 className="text-xl font-bold text-yellow-400 mb-4">📅 Posture Healing Timeline</h3>
        <div className="space-y-3">
          {[
            { week: 'Week 1', result: 'Immediate relief from neck pain when applying chin tucks. Become aware of your bad posture (awareness is step 1).', color: 'bg-blue-900/20' },
            { week: 'Week 2–4', result: 'Neck pain reduces 40–60%. Glute bridges begin activating dormant glutes. Pelvic tilt awareness develops.', color: 'bg-indigo-900/20' },
            { week: 'Month 2–3', result: 'Consistent correction. Friends notice you stand differently. Natural posture improving even without conscious effort.', color: 'bg-purple-900/20' },
            { week: 'Month 4–6', result: 'Neck pain mostly resolved. Pelvic tilt significantly corrected. Voice naturally deeper from better posture.', color: 'bg-orange-900/20' },
            { week: 'Month 6–12', result: 'Full correction with consistent training. Your calisthenics training maintains it automatically. Iron posture.', color: 'bg-green-900/20' },
          ].map((item) => (
            <div key={item.week} className={`${item.color} rounded-xl p-4`}>
              <div className="text-white font-bold mb-1">{item.week}</div>
              <div className="text-gray-300 text-sm">{item.result}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
