function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function RoadmapPlan() {
  const quarters = [
    {
      q: 'Q1',
      months: 'Month 1–3',
      title: 'Foundation & Healing',
      phase: 'Phase 1',
      color: 'from-blue-600 to-blue-900',
      border: 'border-blue-500/40',
      badge: 'bg-blue-500/20 text-blue-300',
      targets: {
        weight: '120kg → 108–112kg',
        body: 'Begin losing fat. Energy improving.',
        fitness: 'Wall push-ups, bodyweight squats, daily walking',
        mental: 'Start journaling. Cold showers. 1 stranger daily.',
        hair: 'Start Minoxidil + Biotin. Month 2 shedding is NORMAL.',
        voice: 'Morning breathing exercises daily.',
        posture: 'Chin tucks + glute bridges — every single day.',
        medical: 'ALL blood tests done. All specialists visited.',
      },
      actions: [
        '✅ Visit endocrinologist + cardiologist + dermatologist',
        '✅ Get complete blood panel done',
        '✅ Start Minoxidil 5% application (2x daily)',
        '✅ Follow diet plan — 1800–2000 calories',
        '✅ Walk 30–45 mins daily (NO EXCUSES)',
        '✅ Begin neck correction exercises',
        '✅ Start journaling + morning breathing',
        '✅ Gyno surgery follow-up check at week 6',
        '✅ Download: Headspace / Wim Hof app',
        '✅ Buy: Resistance bands, door pull-up bar',
      ],
    },
    {
      q: 'Q2',
      months: 'Month 4–6',
      title: 'Build Momentum',
      phase: 'Phase 2 Begins',
      color: 'from-orange-600 to-orange-900',
      border: 'border-orange-500/40',
      badge: 'bg-orange-500/20 text-orange-300',
      targets: {
        weight: '108kg → 95–100kg',
        body: 'Fat melting. People starting to notice.',
        fitness: 'Real push-ups, knee-assisted pull-ups, HIIT 3x/week',
        mental: 'Reading stoic books. 6-week confidence program done.',
        hair: 'First signs of new hair growth. Stay committed.',
        voice: 'Chest resonance developing. Record weekly.',
        posture: 'Neck pain significantly reduced. Pelvic tilt improving.',
        medical: 'Blood test follow-up. Adjust supplements as needed.',
      },
      actions: [
        '✅ Begin HIIT sessions 3x/week',
        '✅ Add chest exercises (surgeon cleared you)',
        '✅ Start BJJ or Muay Thai class (1x/week)',
        '✅ Complete first stoic book (Meditations)',
        '✅ 6-week confidence challenges done',
        '✅ Skin care routine started (face structure)',
        '✅ Consider finasteride prescription (consult doctor)',
        '✅ Face exercises for jawline definition',
        '✅ Measure waist — should be below 40"',
        '✅ Visible arm muscle beginning to show',
      ],
    },
    {
      q: 'Q3',
      months: 'Month 7–9',
      title: 'Visible Transformation',
      phase: 'Phase 2 Advanced',
      color: 'from-yellow-600 to-yellow-900',
      border: 'border-yellow-500/40',
      badge: 'bg-yellow-500/20 text-yellow-300',
      targets: {
        weight: '95kg → 85–88kg',
        body: 'Noticeable muscle definition. Face slimmer. Confidence high.',
        fitness: '15+ push-ups, 5 pull-ups, running 3km',
        mental: 'Stress management mastered. Family pressure handled.',
        hair: 'Visible hair regrowth. Density improved.',
        voice: 'Measurably deeper. Recording evidence over 9 months.',
        posture: 'Posture correction complete. Stand like a warrior.',
        medical: 'Full health reassessment. BMI approaching healthy range.',
      },
      actions: [
        '✅ 3km run without stopping',
        '✅ 15 proper push-ups in one set',
        '✅ 5 full pull-ups (the hardest milestone for beginners)',
        '✅ Waist below 38"',
        '✅ New professional headshots (you look different)',
        '✅ Voice recording comparison — 9 months of change',
        '✅ Financial plan — 3-month emergency fund started',
        '✅ Enrolled in self-defense class',
        '✅ First major plateau — PUSH THROUGH IT',
        '✅ Update wardrobe (old clothes too big — WIN)',
      ],
    },
    {
      q: 'Q4',
      months: 'Month 10–12',
      title: 'One Year Mark',
      phase: 'Phase 3 Begins',
      color: 'from-green-600 to-green-900',
      border: 'border-green-500/40',
      badge: 'bg-green-500/20 text-green-300',
      targets: {
        weight: '85kg → 78–82kg',
        body: 'Visible abs beginning. Muscular arms. Jaw defined.',
        fitness: '20+ push-ups, 10 pull-ups, muscle-up attempt',
        mental: 'Unshakeable baseline. Handle stress with discipline.',
        hair: 'Full regrowth protocol ongoing. Density 60–70% improved.',
        voice: 'Deep, commanding voice established as natural.',
        posture: 'Perfect automatic posture. Zero neck pain.',
        medical: 'Possibly off blood pressure meds if was on them.',
      },
      actions: [
        '✅ ONE YEAR TRANSFORMATION PHOTO — Compare with Day 1',
        '✅ 10 full pull-ups — ELITE milestone',
        '✅ Six pack at 10–12% body fat approaching',
        '✅ Run 5km',
        '✅ Self-defense — able to handle most situations',
        '✅ Voice deeper than when you started',
        '✅ Hair full and growing',
        '✅ Zero neck pain',
        '✅ Financial stability improving',
        '✅ CELEBRATE — you have done what 99% cannot',
      ],
    },
    {
      q: 'Q5–Q6',
      months: 'Month 13–18',
      title: 'Athlete Mode',
      phase: 'Phase 3 Elite',
      color: 'from-purple-600 to-purple-900',
      border: 'border-purple-500/40',
      badge: 'bg-purple-500/20 text-purple-300',
      targets: {
        weight: '78kg → 72–75kg',
        body: 'Clear six-pack visible at under 12% body fat.',
        fitness: 'Muscle-ups, handstands, front lever tuck, L-sit',
        mental: 'Mentor others. Lead by example. Iron confidence.',
        hair: 'Maximum regrowth achieved. Maintenance phase.',
        voice: 'Command any room effortlessly.',
        posture: 'Elite athlete posture — automatic and natural.',
        medical: 'Annual health review — all markers excellent.',
      },
      actions: [
        '✅ First Muscle-Up (the most satisfying achievement)',
        '✅ Handstand hold against wall — 30 seconds',
        '✅ Six-pack visible in morning light',
        '✅ Help someone else start their journey',
        '✅ Consider outdoor calisthenics park training',
        '✅ Advanced BJJ belt progression',
        '✅ Financial: side income established',
        '✅ Social circle upgraded — surrounding powerful people',
        '✅ Face is chiseled — jaw defined, cheekbones visible',
      ],
    },
    {
      q: 'Q7–Q8',
      months: 'Month 19–24',
      title: 'IRON MAN — Final Form',
      phase: 'Phase 4 COMPLETE',
      color: 'from-red-600 to-red-900',
      border: 'border-red-500/40',
      badge: 'bg-red-500/20 text-red-300',
      targets: {
        weight: '70–73kg',
        body: 'Full calisthenics athlete physique. Six-pack. V-taper.',
        fitness: 'Strict muscle-ups, handstand push-ups, one-arm push-up',
        mental: 'Unbreakable. Inspirational to others.',
        hair: 'Full, healthy hair. Maintained indefinitely.',
        voice: 'Deep, resonant, commanding voice.',
        posture: 'Perfect warrior posture — automatic.',
        medical: 'Biological age 10 years younger than chronological.',
      },
      actions: [
        '🏆 TARGET WEIGHT ACHIEVED: 70kg',
        '🏆 Six-pack abs visible',
        '🏆 Strict muscle-ups',
        '🏆 Handstand push-ups',
        '🏆 Complete hair regrowth',
        '🏆 Deep commanding voice',
        '🏆 Zero neck pain, perfect posture',
        '🏆 Confident, unbreakable mindset',
        '🏆 Financially improving',
        '🏆 MOST POWERFUL VERSION OF YOU — ACHIEVED',
      ],
    },
  ];

  const weeklyChecklist = [
    { item: 'Workout (4–5 sessions)', category: 'Physical' },
    { item: 'Daily walking (30+ mins)', category: 'Physical' },
    { item: 'Hit protein target (150–180g)', category: 'Diet' },
    { item: 'No junk food this week', category: 'Diet' },
    { item: 'Water 4+ liters daily', category: 'Diet' },
    { item: 'Journaling daily (5 mins)', category: 'Mental' },
    { item: 'Cold shower daily', category: 'Mental' },
    { item: 'Minoxidil 2x daily (no miss)', category: 'Hair' },
    { item: 'Voice exercises 30 mins', category: 'Voice' },
    { item: 'Neck exercises + posture check', category: 'Posture' },
    { item: 'All supplements taken', category: 'Medical' },
    { item: 'Sleep 7.5+ hours nightly', category: 'Recovery' },
    { item: 'No late night screen time', category: 'Recovery' },
    { item: 'Weekly progress photo', category: 'Tracking' },
    { item: 'Weight recorded (same time)', category: 'Tracking' },
  ];

  const categoryColors: Record<string, string> = {
    Physical: 'bg-orange-500/20 text-orange-300',
    Diet: 'bg-green-500/20 text-green-300',
    Mental: 'bg-blue-500/20 text-blue-300',
    Hair: 'bg-purple-500/20 text-purple-300',
    Voice: 'bg-pink-500/20 text-pink-300',
    Posture: 'bg-yellow-500/20 text-yellow-300',
    Medical: 'bg-red-500/20 text-red-300',
    Recovery: 'bg-cyan-500/20 text-cyan-300',
    Tracking: 'bg-gray-500/20 text-gray-300',
  };

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🗺️</span>
          <h2 className="text-3xl font-black text-white">24-Month Roadmap</h2>
        </div>
        <p className="text-gray-400 ml-14">Your complete 2-year blueprint — quarter by quarter, milestone by milestone</p>
      </div>

      {/* The Iron Promise */}
      <Card className="border-orange-500/40 bg-gradient-to-br from-orange-900/20 to-red-900/20">
        <div className="text-center">
          <div className="text-5xl mb-3">⚡</div>
          <h3 className="text-2xl font-black text-white mb-3">THE IRON PROMISE</h3>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto leading-relaxed">
            "I commit to this plan for <strong className="text-orange-400">730 days</strong>. I will not quit when it's hard. I will not quit when I'm tired. I will not quit when I don't see results yet. Because I know that <strong className="text-white">every single day I show up</strong> is a day my body, mind, and life gets better. The man I will become in 2 years is worth every sacrifice I make today."
          </p>
        </div>
      </Card>

      {/* Quarterly Roadmap */}
      <div className="space-y-6">
        <h3 className="text-xl font-bold text-white">📅 Quarter-by-Quarter Plan</h3>
        {quarters.map((q) => (
          <div key={q.q} className={`border rounded-2xl overflow-hidden ${q.border}`}>
            {/* Header */}
            <div className={`bg-gradient-to-r ${q.color} p-5`}>
              <div className="flex items-center gap-4">
                <div className="bg-white/20 rounded-xl px-4 py-2 text-white font-black text-2xl">{q.q}</div>
                <div>
                  <div className="text-white font-black text-xl">{q.title}</div>
                  <div className="text-white/70 text-sm">{q.months} • {q.phase}</div>
                </div>
              </div>
            </div>

            <div className="p-5 bg-gray-800/40">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Targets */}
                <div>
                  <h4 className="text-gray-300 font-semibold mb-3 text-sm uppercase tracking-wide">Target Milestones</h4>
                  <div className="space-y-2">
                    {Object.entries(q.targets).map(([key, val]) => (
                      <div key={key} className="flex items-start gap-2 text-sm">
                        <span className="text-gray-500 capitalize w-20 flex-shrink-0">{key}:</span>
                        <span className="text-gray-300">{val}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div>
                  <h4 className="text-gray-300 font-semibold mb-3 text-sm uppercase tracking-wide">Action Items</h4>
                  <div className="space-y-1.5">
                    {q.actions.map((action) => (
                      <div key={action} className={`text-xs px-3 py-2 rounded-lg ${q.badge}`}>
                        {action}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Weekly Checklist */}
      <Card className="border-green-500/30">
        <h3 className="text-xl font-bold text-green-400 mb-5">✅ Weekly Non-Negotiable Checklist</h3>
        <p className="text-gray-400 text-sm mb-4">Print this or save it. Every Sunday, check how many you completed. Target: 14/15 every week.</p>
        <div className="grid md:grid-cols-3 gap-3">
          {weeklyChecklist.map((item, i) => (
            <div key={item.item} className="bg-gray-700/30 rounded-xl p-3 flex items-center gap-3">
              <div className="w-6 h-6 border-2 border-gray-600 rounded flex-shrink-0 flex items-center justify-center text-gray-600 text-xs font-bold">
                {i + 1}
              </div>
              <div className="flex-1">
                <div className="text-gray-300 text-xs">{item.item}</div>
                <span className={`text-xs px-2 py-0.5 rounded-full mt-1 inline-block ${categoryColors[item.category]}`}>
                  {item.category}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Rules of the Iron Man */}
      <Card className="border-red-500/30 bg-red-900/10">
        <h3 className="text-xl font-bold text-red-400 mb-4">🔥 The 10 Iron Laws — NEVER Break These</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {[
            { law: '1. Sleep is non-negotiable', rule: '7.5 hours minimum. No exceptions. Miss sleep = miss gains, miss hormone production, miss fat loss.' },
            { law: '2. Never skip Monday', rule: 'Starting the week strong creates momentum. A week lost is a week that never returns.' },
            { law: '3. Protein first, every meal', rule: 'Build your plate around protein. Everything else fills in after.' },
            { law: '4. No junk food at home', rule: 'If it\'s not in the house, you can\'t eat it. Control your environment.' },
            { law: '5. Minoxidil — twice daily, always', rule: 'Missing even 2 days can reset 2 months of progress. Non-negotiable.' },
            { law: '6. Phone down after 9 PM', rule: 'Blue light kills melatonin. Bad sleep kills testosterone. Kills everything.' },
            { law: '7. One set of exercises beats zero', rule: 'Even on the worst day — do 10 push-ups. Momentum matters more than volume.' },
            { law: '8. Weigh yourself weekly, not daily', rule: 'Daily fluctuations are water/food. Weekly trend shows real progress.' },
            { law: '9. Progress photos monthly', rule: 'Your brain adapts to your body. Photos show what your eyes miss.' },
            { law: '10. Help someone every day', rule: 'Generosity releases oxytocin. Strong men lift others. This builds true confidence.' },
          ].map((item) => (
            <div key={item.law} className="bg-red-900/20 rounded-xl p-4">
              <div className="text-red-300 font-bold text-sm mb-1">{item.law}</div>
              <div className="text-gray-400 text-xs">{item.rule}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Final Motivation */}
      <Card className="border-yellow-500/30 bg-gradient-to-br from-yellow-900/20 to-orange-900/20">
        <div className="text-center py-4">
          <div className="text-6xl mb-4">🏆</div>
          <h3 className="text-3xl font-black text-white mb-4">YOU WILL BECOME UNSTOPPABLE</h3>
          <div className="max-w-3xl mx-auto space-y-3 text-gray-300">
            <p>
              In 2 years, you will look in the mirror and not recognize the person looking back — <strong className="text-orange-400">in the best possible way.</strong>
            </p>
            <p>
              The people who judged you, the bullies who beat you, the family stress that broke you — all of that will become <strong className="text-yellow-400">fuel for your fire.</strong>
            </p>
            <p>
              You will stand at <strong className="text-green-400">70kg of pure muscle and discipline</strong>, with a voice that commands rooms, hair that grows full, a mind that bends steel, and a body that performs miracles.
            </p>
            <p className="text-xl font-black text-white pt-4">
              "The strongest version of you is not born. He is BUILT — one day, one rep, one meal, one decision at a time."
            </p>
            <p className="text-orange-400 text-lg font-bold">
              Start today. The 2 years will pass anyway. ⚡
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
