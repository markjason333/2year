function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function VoicePlan() {
  const voiceExercises = [
    {
      name: 'Diaphragmatic Breathing',
      duration: '5 minutes daily',
      how: 'Lie flat. Place hand on belly. Breathe deeply so belly rises (NOT chest). Inhale 4 sec, hold 2 sec, exhale 6 sec slowly. This builds breath support — the foundation of a deep, powerful voice.',
      benefit: 'More air = lower, richer, more resonant voice',
      icon: '🌬️',
    },
    {
      name: 'Humming Resonance Exercise',
      duration: '5 minutes daily',
      how: 'Hum with lips closed at your natural pitch. Slowly drop the pitch lower and lower until you feel vibration in your CHEST (not just throat). This is your chest voice. Practice holding this for 10-second intervals.',
      benefit: 'Trains chest resonance — deepens perceived voice pitch',
      icon: '🎵',
    },
    {
      name: 'Yawn-Sigh Technique',
      duration: '3 minutes daily',
      how: 'Yawn naturally and deeply. As you exhale the yawn, let it turn into a SIGH on a low pitch. This stretches and opens the vocal tract. Do 10 repetitions. This is used by professional voice actors.',
      benefit: 'Opens larynx, drops voice naturally',
      icon: '😮',
    },
    {
      name: 'The "Om" Vibration',
      duration: '5 minutes daily',
      how: 'Sit upright. Inhale deeply. Exhale "OHHMMM" on the lowest pitch you can sustain. Feel the vibration in your chest and belly. This is Sanskrit vocal training that deepens resonance.',
      benefit: 'Massive chest resonance development + stress relief',
      icon: '🕉️',
    },
    {
      name: 'Slow Deliberate Speech Practice',
      duration: '10 minutes daily',
      how: 'Read any text ALOUD slowly. Aim for 120 words per minute (normal is 150–180). This reduces vocal tension and allows your voice to settle into a deeper register naturally.',
      benefit: 'Deeper, more authoritative perceived tone',
      icon: '📖',
    },
    {
      name: 'Jaw & Neck Release',
      duration: '3 minutes daily',
      how: 'Gently open jaw as wide as comfortable and hold 5 sec. Slowly rotate neck. Tense neck muscles raise voice pitch. Release = deeper voice.',
      benefit: 'Removes tension that raises pitch',
      icon: '🔄',
    },
    {
      name: 'Pitch Gliding',
      duration: '5 minutes daily',
      how: 'Start at your normal pitch and slide DOWN as low as you can comfortably go. Hold at the lowest comfortable point for 5 seconds. Don\'t strain — gentle downward extension builds range over time.',
      benefit: 'Expands lower vocal range',
      icon: '📉',
    },
    {
      name: 'Sentence Recording Practice',
      duration: '10 minutes daily',
      how: 'Record yourself reading sentences. Listen back. Identify what sounds weak/high. Practice the same sentence with different techniques — slower, deeper, more chest resonance.',
      benefit: 'Most effective feedback tool for voice training',
      icon: '🎙️',
    },
  ];

  const lifeFactors = [
    {
      factor: 'Exercise & Testosterone',
      impact: 'High',
      detail: 'Heavy exercise (especially compound movements) boosts testosterone. Testosterone thickens vocal folds = permanently deeper voice over time. Your workout plan DIRECTLY deepens your voice.',
      action: 'Follow the physical training plan religiously',
      color: 'bg-green-900/20 border-green-700/30',
    },
    {
      factor: 'Body Fat Reduction',
      impact: 'High',
      detail: 'Excess fat increases estrogen (which can raise voice pitch). Losing 50kg will directly impact your hormonal balance and voice. Many men report voice deepening after significant weight loss.',
      action: 'Follow the diet plan. Lose the fat.',
      color: 'bg-orange-900/20 border-orange-700/30',
    },
    {
      factor: 'Posture',
      impact: 'Very High',
      detail: 'Slouching COMPRESSES the chest cavity and restricts vocal resonance. Standing tall with chest out and chin parallel to floor immediately deepens your voice 15–20% — no training needed.',
      action: 'See Posture Plan tab. Fix this FIRST.',
      color: 'bg-blue-900/20 border-blue-700/30',
    },
    {
      factor: 'Hydration',
      impact: 'Medium',
      detail: 'Dehydrated vocal folds are stiff and produce higher, thinner voice. 4 liters of water daily keeps vocal folds supple and flexible.',
      action: 'Follow hydration protocol. Avoid dry air AC.',
      color: 'bg-cyan-900/20 border-cyan-700/30',
    },
    {
      factor: 'Avoid Smoking/Alcohol',
      impact: 'High',
      detail: 'Smoking thickens vocal folds in ways that cause hoarseness (NOT depth). Alcohol dehydrates. Both damage your voice long-term.',
      action: 'Zero tolerance policy.',
      color: 'bg-red-900/20 border-red-700/30',
    },
  ];

  const deliveryTips = [
    { tip: 'Speak 20% SLOWER', reason: 'Slower speech sounds more authoritative and naturally allows your voice to sit lower.' },
    { tip: 'End sentences DOWN, not UP', reason: 'Upward inflection at sentence end sounds weak/questioning. Downward = confident statement.' },
    { tip: 'Pause strategically', reason: 'A 2-second pause before answering makes you seem thoughtful and commands respect.' },
    { tip: 'Project from chest, not throat', reason: 'Voice from throat = thin and strained. Voice from chest = powerful and deep.' },
    { tip: 'Eliminate filler words', reason: '"Um", "like", "you know" destroy authority. Replace with silence/pause.' },
    { tip: 'Volume control', reason: 'Don\'t speak softly — project. Soft voice = low confidence perception.' },
  ];

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🎙️</span>
          <h2 className="text-3xl font-black text-white">Voice Deepening Plan</h2>
        </div>
        <p className="text-gray-400 ml-14">Transform your voice from light to commanding — through training, lifestyle & hormonal optimization</p>
      </div>

      {/* How Voice Depth Works */}
      <Card className="border-yellow-500/30 bg-yellow-900/10">
        <h3 className="text-lg font-bold text-yellow-400 mb-3">🔬 Science of Voice Deepening</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h4 className="text-white font-semibold text-sm mb-2">What Determines Voice Depth:</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex gap-2"><span className="text-yellow-400">→</span> Size of vocal folds (testosterone grows them)</li>
              <li className="flex gap-2"><span className="text-yellow-400">→</span> Chest cavity size (bigger chest = deeper resonance)</li>
              <li className="flex gap-2"><span className="text-yellow-400">→</span> Posture (compressed vs open chest)</li>
              <li className="flex gap-2"><span className="text-yellow-400">→</span> Vocal habits (where resonance is placed)</li>
              <li className="flex gap-2"><span className="text-yellow-400">→</span> Body fat percentage (fat → estrogen → higher pitch)</li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold text-sm mb-2">What You CAN Change:</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex gap-2"><span className="text-green-400">✓</span> Chest resonance placement (training)</li>
              <li className="flex gap-2"><span className="text-green-400">✓</span> Body posture (immediate effect)</li>
              <li className="flex gap-2"><span className="text-green-400">✓</span> Speaking speed and delivery style</li>
              <li className="flex gap-2"><span className="text-green-400">✓</span> Testosterone levels (exercise + diet)</li>
              <li className="flex gap-2"><span className="text-green-400">✓</span> Body fat reduction (hormonal impact)</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* Daily Practice */}
      <Card className="border-blue-500/30">
        <h3 className="text-xl font-bold text-blue-400 mb-2">🎯 Daily Voice Training Routine (30 Minutes)</h3>
        <p className="text-gray-400 text-sm mb-5">Best time: 5:45 AM after waking. Voice is at its deepest in the morning — train at this depth to set the muscle memory.</p>
        <div className="grid md:grid-cols-2 gap-4">
          {voiceExercises.map((ex) => (
            <div key={ex.name} className="bg-gray-700/30 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl">{ex.icon}</span>
                <div>
                  <div className="text-white font-bold text-sm">{ex.name}</div>
                  <div className="text-blue-400 text-xs">{ex.duration}</div>
                </div>
              </div>
              <p className="text-gray-400 text-xs mb-2 leading-relaxed">{ex.how}</p>
              <div className="bg-blue-900/20 rounded-lg px-3 py-1.5 text-blue-300 text-xs">
                ✨ {ex.benefit}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Life Factors */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4">⚡ Lifestyle Factors That Deepen Your Voice</h3>
        <div className="space-y-3">
          {lifeFactors.map((item) => (
            <Card key={item.factor} className={`border ${item.color}`}>
              <div className="flex items-start justify-between gap-4 mb-2">
                <h4 className="text-white font-bold">{item.factor}</h4>
                <span className={`text-xs font-bold px-2 py-1 rounded-full flex-shrink-0 ${
                  item.impact === 'Very High' ? 'bg-red-500/20 text-red-300' :
                  item.impact === 'High' ? 'bg-orange-500/20 text-orange-300' :
                  'bg-yellow-500/20 text-yellow-300'
                }`}>Impact: {item.impact}</span>
              </div>
              <p className="text-gray-400 text-sm mb-2">{item.detail}</p>
              <div className="bg-gray-700/40 rounded-lg p-2 text-green-400 text-xs font-medium">
                ✅ Action: {item.action}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Delivery Tips */}
      <Card className="border-orange-500/30">
        <h3 className="text-xl font-bold text-orange-400 mb-4">🗣️ Instant Voice Authority Tips</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {deliveryTips.map((item) => (
            <div key={item.tip} className="bg-gray-700/30 rounded-xl p-4">
              <div className="text-white font-bold text-sm mb-1">{item.tip}</div>
              <div className="text-gray-400 text-xs">{item.reason}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Timeline */}
      <Card className="border-green-500/30">
        <h3 className="text-xl font-bold text-green-400 mb-4">📅 Voice Transformation Timeline</h3>
        <div className="space-y-3">
          {[
            { period: 'Week 1–2', result: 'Immediate 10–15% deeper with proper posture and chest resonance placement. People notice.', color: 'bg-blue-900/20' },
            { period: 'Month 1–2', result: 'Consistent daily practice builds chest resonance habit. Voice naturally settles lower.', color: 'bg-indigo-900/20' },
            { period: 'Month 3–6', result: 'Combined with fat loss + exercise, hormonal improvements start deepening vocal folds.', color: 'bg-purple-900/20' },
            { period: 'Month 6–12', result: 'Significant voice deepening from: (1) weight loss, (2) testosterone improvement, (3) trained technique.', color: 'bg-orange-900/20' },
            { period: 'Month 12–24', result: 'Maximum natural depth achieved. Your voice matches your new powerful physique — deep, resonant, commanding.', color: 'bg-green-900/20' },
          ].map((item) => (
            <div key={item.period} className={`${item.color} rounded-xl p-4`}>
              <div className="text-white font-bold mb-1">{item.period}</div>
              <div className="text-gray-300 text-sm">{item.result}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
