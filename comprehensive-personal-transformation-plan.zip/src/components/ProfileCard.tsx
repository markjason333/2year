export default function ProfileCard() {
  const stats = [
    { icon: '📅', label: 'Age', value: '24 years (Born 2001)' },
    { icon: '⚖️', label: 'Current Weight', value: '120 kg → Target 70 kg' },
    { icon: '📏', label: 'Height', value: "6'1\" (185 cm)" },
    { icon: '📐', label: 'Waist', value: '44" → Target 32"' },
    { icon: '🍃', label: 'Diet', value: 'Pure Vegetarian' },
    { icon: '💼', label: 'Job', value: 'Security Consultant (Sedentary)' },
    { icon: '🏥', label: 'Recent Surgery', value: 'Gynecomastia (Post-Op)' },
    { icon: '🎯', label: 'Goal', value: 'Pro Calisthenics + Six Pack' },
  ];

  const challenges = [
    { icon: '🦱', text: 'Hair Fall' },
    { icon: '🗣️', text: 'Light Voice' },
    { icon: '🪑', text: 'Neck Pain & Pelvic Tilt' },
    { icon: '💪', text: 'Thin Weak Arms' },
    { icon: '😟', text: 'Emotional & Stressed' },
    { icon: '🧠', text: 'Low Confidence' },
    { icon: '😴', text: 'Family & Money Stress' },
    { icon: '🛡️', text: 'Physical Weakness' },
  ];

  return (
    <section className="bg-gray-900 border-b border-gray-800 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black text-white mb-2">
            🎯 Your <span className="text-orange-400">Personal Profile</span> Analysis
          </h2>
          <p className="text-gray-400">Every plan below is customized based on YOUR unique situation</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Stats */}
          <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
            <h3 className="text-orange-400 font-bold text-lg mb-4 flex items-center gap-2">
              <span>📊</span> Your Current Stats
            </h3>
            <div className="grid grid-cols-1 gap-3">
              {stats.map((stat) => (
                <div key={stat.label} className="flex items-center gap-3 bg-gray-700/40 rounded-xl p-3">
                  <span className="text-2xl">{stat.icon}</span>
                  <div>
                    <div className="text-gray-400 text-xs">{stat.label}</div>
                    <div className="text-white font-semibold text-sm">{stat.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Challenges */}
          <div>
            <div className="bg-red-900/20 border border-red-800/40 rounded-2xl p-6 mb-4">
              <h3 className="text-red-400 font-bold text-lg mb-4 flex items-center gap-2">
                <span>⚠️</span> Current Challenges
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {challenges.map((c) => (
                  <div key={c.text} className="flex items-center gap-2 bg-red-900/20 rounded-xl p-3">
                    <span className="text-xl">{c.icon}</span>
                    <span className="text-gray-300 text-sm font-medium">{c.text}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-green-900/20 border border-green-800/40 rounded-2xl p-6">
              <h3 className="text-green-400 font-bold text-lg mb-4 flex items-center gap-2">
                <span>🏆</span> Your Future Self (2 Years)
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: '💪', text: '70kg Lean Muscle' },
                  { icon: '🎖️', text: 'Six-Pack Abs' },
                  { icon: '🦁', text: 'Iron Confidence' },
                  { icon: '🎙️', text: 'Deep Strong Voice' },
                  { icon: '🦱', text: 'Full Hair Growth' },
                  { icon: '🧠', text: 'Steel Mindset' },
                  { icon: '🦴', text: 'Strong Dense Bones' },
                  { icon: '🕐', text: 'Live 100+ Years' },
                ].map((c) => (
                  <div key={c.text} className="flex items-center gap-2 bg-green-900/20 rounded-xl p-3">
                    <span className="text-xl">{c.icon}</span>
                    <span className="text-gray-300 text-sm font-medium">{c.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Important Disclaimer */}
        <div className="mt-6 bg-blue-900/20 border border-blue-700/40 rounded-2xl p-4">
          <p className="text-blue-300 text-sm flex items-start gap-2">
            <span className="text-lg flex-shrink-0">⚕️</span>
            <span>
              <strong>Medical Disclaimer:</strong> This plan is an educational guide based on scientific research. Always consult your physician before starting any new exercise or supplement regimen, especially post-surgery. The medical suggestions here are general and should be reviewed by a qualified healthcare professional. Your gynecomastia surgery recovery must be cleared by your surgeon before attempting chest exercises.
            </span>
          </p>
        </div>
      </div>
    </section>
  );
}
