function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function MentalPlan() {
  const dailyMindset = [
    {
      time: '5:30 AM',
      practice: 'Morning Stoic Affirmation',
      desc: 'Before touching your phone, repeat: "I control my actions, not others\' opinions. Today I become stronger." Journal 3 things you\'re grateful for.',
      icon: '🌅',
    },
    {
      time: '5:45 AM',
      practice: 'Cold Shower Therapy',
      desc: 'After workout — 2-3 minutes cold shower. Proven to increase norepinephrine by 300%, reduce anxiety, build mental toughness. Start with 30 seconds, increase weekly.',
      icon: '🧊',
    },
    {
      time: '8:00 AM',
      practice: 'The "5-Second Rule" at Work',
      desc: 'When you feel stress or anxiety at work: count 5-4-3-2-1, then act. Mel Robbins method breaks overthinking cycles instantly.',
      icon: '⏱️',
    },
    {
      time: '1:00 PM',
      practice: 'Midday Meditation',
      desc: '5–10 min box breathing at lunch: Inhale 4 sec → Hold 4 sec → Exhale 4 sec → Hold 4 sec. Resets cortisol. Use Headspace or Insight Timer app.',
      icon: '🧘',
    },
    {
      time: '9:30 PM',
      practice: 'Evening Journaling',
      desc: 'Write: 1) What did I do well today? 2) What can I improve? 3) What am I worried about and what CAN I control? This transforms emotional overwhelm into action.',
      icon: '📖',
    },
  ];

  const stoicLessons = [
    {
      philosopher: 'Marcus Aurelius',
      lesson: '"You have power over your mind, not outside events. Realize this and you will find strength."',
      action: 'When family stresses you: write what you CAN control (your response) vs CANNOT control (their behavior). Act only on what you can control.',
      color: 'border-gold-400 bg-amber-900/20',
    },
    {
      philosopher: 'Epictetus',
      lesson: '"It is not the things that disturb us, but our judgments about them."',
      action: 'When someone beats you or disrespects you: their action reveals THEIR character, not yours. Your only job is to get stronger and smarter.',
      color: 'bg-blue-900/20 border-blue-700/30',
    },
    {
      philosopher: 'Seneca',
      lesson: '"Per aspera ad astra — Through hardship to the stars."',
      action: 'Every financial problem, every social judgment — these are your forge. Iron becomes steel only under fire. You are being forged.',
      color: 'bg-purple-900/20 border-purple-700/30',
    },
  ];

  const confidenceBuilders = [
    {
      title: 'Power Posing Daily',
      desc: 'Before any challenge — 2 minutes of Superman pose (hands on hips, chest out, chin up). Harvard studies show this increases testosterone 20% and reduces cortisol 25%.',
      icon: '🦸',
      week: 'Week 1',
    },
    {
      title: 'Eye Contact Training',
      desc: 'Practice holding eye contact for 3-5 seconds minimum. Start with mirror practice. Then with shopkeepers, then colleagues. Do NOT look down — it signals submission.',
      icon: '👁️',
      week: 'Week 2',
    },
    {
      title: 'Speak to One Stranger Daily',
      desc: 'Introvert cure: speak to 1 stranger per day. Even asking directions counts. Each interaction builds courage circuits in the amygdala. Track it in your journal.',
      icon: '🗣️',
      week: 'Week 3',
    },
    {
      title: 'Say NO Without Explaining',
      desc: 'Practice saying "No" to things that drain you. You don\'t owe anyone an explanation. Boundaries = respect. People who drain your energy are the enemy of your transformation.',
      icon: '🚫',
      week: 'Week 4',
    },
    {
      title: 'Physical Space Ownership',
      desc: 'Stand tall, take up space, walk with purpose. Shoulders back. When you enter a room — OWN it. Your posture program directly improves this.',
      icon: '👑',
      week: 'Week 5',
    },
    {
      title: 'Anger to Fuel Protocol',
      desc: 'When someone makes you angry or you feel beaten — immediately do push-ups, sprints, or pull-ups. Convert emotional pain to physical gains. This is how warriors are made.',
      icon: '🔥',
      week: 'Week 6+',
    },
  ];

  const stressManagement = [
    {
      stressor: 'Family Pressure',
      strategy: 'Create physical and mental distance rituals. Earphones + workout = your sanctuary. Family problems are NOT your emergency unless they truly are. Set visiting hours for problems — "I will think about this at 7 PM, not now."',
      color: 'bg-orange-900/20 border-orange-700/30',
    },
    {
      stressor: 'Money Stress',
      strategy: 'The "Financial Attack" mindset: 1) Cut 3 unnecessary expenses TODAY. 2) List every skill you have that can earn. 3) Read "Rich Dad Poor Dad" + "The Psychology of Money". Make a financial plan weekly. Action destroys anxiety.',
      color: 'bg-green-900/20 border-green-700/30',
    },
    {
      stressor: 'Social Judgment',
      strategy: 'Marcus Aurelius: "How much time he gains who does not look to see what his neighbor says or does." Your body transformation will SILENCE critics in 12 months. Let your results be your roar.',
      color: 'bg-blue-900/20 border-blue-700/30',
    },
    {
      stressor: 'Emotional Overwhelm',
      strategy: 'You are NOT too emotional — you are SENSITIVE. This is a SUPERPOWER when channeled. Journaling, art, music, martial arts — use emotion as fuel. Therapy (CBT) is strength, not weakness.',
      color: 'bg-purple-900/20 border-purple-700/30',
    },
    {
      stressor: 'Being Beaten/Bullied',
      strategy: 'IMMEDIATE: Begin learning self-defense — Jiu-Jitsu or Muay Thai (1 class/week). Within 12 months you will be capable of protecting yourself. NEVER fight unless necessary, but KNOW you can. This destroys fear instantly.',
      color: 'bg-red-900/20 border-red-700/30',
    },
  ];

  const books = [
    { title: 'Meditations', author: 'Marcus Aurelius', genre: 'Stoicism' },
    { title: 'Can\'t Hurt Me', author: 'David Goggins', genre: 'Mental Toughness' },
    { title: 'Atomic Habits', author: 'James Clear', genre: 'Behavior Change' },
    { title: 'The Way of The Superior Man', author: 'David Deida', genre: 'Masculinity' },
    { title: 'Mindset', author: 'Carol Dweck', genre: 'Growth Mindset' },
    { title: 'The Power of Now', author: 'Eckhart Tolle', genre: 'Present Moment' },
  ];

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🧠</span>
          <h2 className="text-3xl font-black text-white">Mental Health & Confidence Plan</h2>
        </div>
        <p className="text-gray-400 ml-14">Transform from emotional introvert to confident, unshakeable iron-minded warrior</p>
      </div>

      {/* Key Mental Truth */}
      <Card className="border-yellow-500/30 bg-yellow-900/10">
        <div className="text-center">
          <div className="text-5xl mb-3">⚡</div>
          <h3 className="text-yellow-300 text-2xl font-black mb-3">THE IRON TRUTH</h3>
          <p className="text-gray-300 text-lg leading-relaxed max-w-3xl mx-auto">
            Your body transformation <strong className="text-yellow-400">WILL</strong> transform your mind. As you lose fat, gain muscle, and get stronger — your brain literally produces more testosterone, serotonin, and dopamine. <br /><br />
            <strong className="text-white">Confidence is NOT a personality trait. It is a SKILL built through discipline, small victories, and facing fear daily.</strong>
          </p>
        </div>
      </Card>

      {/* Daily Mental Practice */}
      <Card className="border-blue-500/30">
        <h3 className="text-xl font-bold text-blue-400 mb-5">📅 Daily Mental Conditioning Schedule</h3>
        <div className="space-y-4">
          {dailyMindset.map((item) => (
            <div key={item.time} className="flex gap-4 bg-gray-700/30 rounded-xl p-4">
              <span className="text-3xl flex-shrink-0">{item.icon}</span>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-blue-400 font-mono text-xs">{item.time}</span>
                  <span className="text-white font-bold">{item.practice}</span>
                </div>
                <p className="text-gray-400 text-sm">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Stoic Lessons */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4">📜 Stoic Philosophy — Your Mental Armor</h3>
        <div className="grid gap-4">
          {stoicLessons.map((lesson) => (
            <Card key={lesson.philosopher} className={`border ${lesson.color}`}>
              <div className="font-bold text-orange-400 text-sm mb-2">— {lesson.philosopher}</div>
              <blockquote className="text-white text-lg font-medium italic mb-3 border-l-4 border-orange-500 pl-4">
                {lesson.lesson}
              </blockquote>
              <div className="bg-gray-700/40 rounded-xl p-3">
                <span className="text-green-400 font-semibold text-sm">Your Action: </span>
                <span className="text-gray-300 text-sm">{lesson.action}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Confidence Builders */}
      <Card className="border-purple-500/30">
        <h3 className="text-xl font-bold text-purple-400 mb-5">👑 6-Week Confidence Building Protocol</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {confidenceBuilders.map((item) => (
            <div key={item.title} className="bg-gray-700/30 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl">{item.icon}</span>
                <div>
                  <span className="text-purple-400 text-xs font-bold bg-purple-500/20 px-2 py-0.5 rounded-full">
                    {item.week}
                  </span>
                  <h4 className="text-white font-bold text-sm">{item.title}</h4>
                </div>
              </div>
              <p className="text-gray-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Stress Management */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4">🛡️ Stress Warfare — Handling Your Battles</h3>
        <div className="space-y-4">
          {stressManagement.map((item) => (
            <Card key={item.stressor} className={`border ${item.color}`}>
              <h4 className="text-white font-bold mb-2 flex items-center gap-2">
                <span className="text-red-400">⚠️</span> Stressor: {item.stressor}
              </h4>
              <p className="text-gray-300 text-sm leading-relaxed">{item.strategy}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Self-Defense */}
      <Card className="border-red-500/30 bg-red-900/10">
        <h3 className="text-xl font-bold text-red-400 mb-4 flex items-center gap-2">
          🥋 Self-Defense Training — Never Be Weak Again
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-white font-semibold mb-3">Recommended Martial Arts (Pick 1):</h4>
            <ul className="space-y-2">
              {[
                { art: 'Brazilian Jiu-Jitsu (BJJ)', note: 'BEST for all sizes. Ground control. Defeats bigger opponents.' },
                { art: 'Muay Thai', note: 'Striking power. Builds confidence fast. Great cardio.' },
                { art: 'Wrestling', note: 'Takedown power. Raw dominance.' },
                { art: 'Krav Maga', note: 'Street self-defense system. Practical & fast to learn.' },
              ].map((m) => (
                <li key={m.art} className="bg-red-900/20 rounded-xl p-3">
                  <div className="text-white font-medium text-sm">{m.art}</div>
                  <div className="text-gray-400 text-xs">{m.note}</div>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-3">The Mental Shift from Training:</h4>
            <div className="space-y-2 text-sm text-gray-300">
              <div className="bg-gray-700/30 rounded-xl p-3">✅ You stop being afraid of confrontation</div>
              <div className="bg-gray-700/30 rounded-xl p-3">✅ You carry yourself differently — people sense this</div>
              <div className="bg-gray-700/30 rounded-xl p-3">✅ Bullies target weak energy — martial arts changes your energy</div>
              <div className="bg-gray-700/30 rounded-xl p-3">✅ Even 3 months of BJJ makes you capable of handling average aggressor</div>
              <div className="bg-gray-700/30 rounded-xl p-3">✅ 1 year of training = formidable fighter + unshakeable confidence</div>
            </div>
          </div>
        </div>
      </Card>

      {/* Books */}
      <Card className="border-gray-500/30">
        <h3 className="text-xl font-bold text-white mb-4">📚 Essential Books for Your Transformation</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {books.map((book) => (
            <div key={book.title} className="bg-gray-700/30 rounded-xl p-4 flex items-start gap-3">
              <span className="text-2xl">📗</span>
              <div>
                <div className="text-white font-bold text-sm">"{book.title}"</div>
                <div className="text-gray-400 text-xs">{book.author}</div>
                <div className="text-orange-400 text-xs mt-1 font-medium">{book.genre}</div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Masturbation Note */}
      <Card className="border-gray-600/30 bg-gray-800/30">
        <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
          🔬 Science Note: Masturbation & Your Goals
        </h3>
        <div className="space-y-3 text-sm text-gray-300">
          <p>
            <strong className="text-white">The Science:</strong> Multiple peer-reviewed studies confirm that masturbation frequency (including 2x/day) does <em className="text-green-400">NOT</em> significantly impact testosterone levels long-term. The 7-day abstinence peak is real but temporary (returns to baseline on day 8).
          </p>
          <p>
            <strong className="text-white">What Actually Matters:</strong> Exercise, sleep quality (7.5–8 hrs), nutrition, and low stress are the TRUE testosterone drivers. A person who exercises, eats well, and sleeps correctly will have 40–60% higher testosterone than someone who is sedentary, regardless of masturbation habits.
          </p>
          <p>
            <strong className="text-orange-400">Recommendation:</strong> However, if masturbation is consuming time, draining energy for workouts, or tied to porn addiction, reduce frequency as a lifestyle optimization — not for hormone reasons, but for time, energy, and mental clarity reasons. Channel that energy into your workout, career, and transformation instead.
          </p>
        </div>
      </Card>
    </div>
  );
}
