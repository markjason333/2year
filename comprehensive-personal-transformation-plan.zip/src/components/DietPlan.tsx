function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function DietPlan() {
  const mealPlan = [
    {
      time: '5:30 AM',
      meal: 'Wake-Up Ritual',
      color: 'border-yellow-500/40',
      badge: 'bg-yellow-500/20 text-yellow-300',
      items: [
        '500ml warm water with ½ lemon + pinch of Himalayan salt',
        '5 soaked almonds + 2 soaked walnuts',
        '1 tsp chia seeds (soaked overnight)',
      ],
      macros: 'Protein: 5g | Carbs: 8g | Fat: 14g | Cal: 180',
      benefits: 'Hydration, metabolism boost, brain activation',
    },
    {
      time: '7:30 AM',
      meal: 'Post-Workout Breakfast',
      color: 'border-orange-500/40',
      badge: 'bg-orange-500/20 text-orange-300',
      items: [
        '80g oats cooked in 300ml full-fat milk',
        '1 scoop plant protein powder (or whey if vegetarian allows)',
        '1 banana + 1 tbsp peanut butter',
        '2 tbsp pumpkin seeds',
      ],
      macros: 'Protein: 45g | Carbs: 90g | Fat: 18g | Cal: 710',
      benefits: 'Muscle recovery, glycogen replenishment, hair nutrients (biotin from nuts)',
    },
    {
      time: '11:00 AM',
      meal: 'Mid-Morning Snack',
      color: 'border-blue-500/40',
      badge: 'bg-blue-500/20 text-blue-300',
      items: [
        '200ml buttermilk (chaas) with cumin powder',
        '30g roasted chana (Bengal gram)',
        '1 medium guava or 1 orange',
      ],
      macros: 'Protein: 14g | Carbs: 30g | Fat: 4g | Cal: 210',
      benefits: 'Gut health, probiotics, Vitamin C for collagen + hair',
    },
    {
      time: '1:00 PM',
      meal: 'Power Lunch',
      color: 'border-green-500/40',
      badge: 'bg-green-500/20 text-green-300',
      items: [
        '2–3 chapati (whole wheat) or 1 cup brown rice',
        '1.5 cups rajma/chole/moong dal',
        '100g paneer bhurji with turmeric + black pepper',
        'Large salad: cucumber, tomato, onion, lemon',
        '1 cup low-fat curd/yogurt',
      ],
      macros: 'Protein: 55g | Carbs: 110g | Fat: 22g | Cal: 860',
      benefits: 'Complete amino acids, iron (dal+vitamin C combo), probiotics',
    },
    {
      time: '4:00 PM',
      meal: 'Pre-Workout Fuel',
      color: 'border-purple-500/40',
      badge: 'bg-purple-500/20 text-purple-300',
      items: [
        '1 banana + 10g jaggery + pinch of salt',
        'OR Peanut butter sandwich (2 slices whole grain)',
        'Green tea or black coffee (no sugar)',
      ],
      macros: 'Protein: 10g | Carbs: 55g | Fat: 8g | Cal: 330',
      benefits: 'Quick energy, electrolytes, mental focus before workout',
    },
    {
      time: '8:00 PM',
      meal: 'Recovery Dinner',
      color: 'border-red-500/40',
      badge: 'bg-red-500/20 text-red-300',
      items: [
        '1 cup quinoa or 2 rotis',
        'Soya chunks curry (100g dry soya) with palak',
        '100g tofu stir-fry with vegetables',
        '1 tbsp ghee (crucial for hormones, bone strength)',
        '1 cup warm turmeric milk (haldi doodh)',
      ],
      macros: 'Protein: 50g | Carbs: 70g | Fat: 20g | Cal: 660',
      benefits: 'Night-time muscle protein synthesis, anti-inflammatory turmeric',
    },
    {
      time: '10:00 PM',
      meal: 'Pre-Sleep Protocol',
      color: 'border-gray-500/40',
      badge: 'bg-gray-500/20 text-gray-300',
      items: [
        '80g cottage cheese (paneer) with black pepper',
        '1 tsp flaxseed powder',
        'Ashwagandha capsule (600mg with warm milk)',
      ],
      macros: 'Protein: 18g | Carbs: 4g | Fat: 8g | Cal: 160',
      benefits: 'Slow-release casein protein for overnight muscle repair, ashwagandha lowers cortisol',
    },
  ];

  const proteinSources = [
    { food: 'Paneer (Cottage Cheese)', per100g: '18–22g', notes: 'All 9 essential amino acids' },
    { food: 'Soya Chunks', per100g: '52g', notes: 'Highest plant protein source' },
    { food: 'Lentils (Dal – all types)', per100g: '9–26g', notes: 'Iron + fiber rich' },
    { food: 'Chickpeas (Chole)', per100g: '19g', notes: 'High in zinc for testosterone' },
    { food: 'Tofu', per100g: '8–15g', notes: 'Calcium + bone strength' },
    { food: 'Greek Yogurt', per100g: '10g', notes: 'Probiotics + protein' },
    { food: 'Milk (Full Fat)', per100ml: '3.5g', notes: 'IGF-1, bone growth' },
    { food: 'Quinoa', per100g: '14g', notes: 'Complete protein grain' },
    { food: 'Whey/Plant Protein', perscoop: '24–30g', notes: 'Post-workout essential' },
    { food: 'Rajma (Kidney Beans)', per100g: '24g', notes: 'Iron + slow carbs' },
  ];

  const supplements = [
    { name: 'Plant-Based Protein Powder', timing: 'Post-workout', dose: '1 scoop (25–30g)', reason: 'Hit daily protein target' },
    { name: 'Creatine Monohydrate', timing: 'Daily with water', dose: '5g/day', reason: 'Strength + muscle gains + brain function' },
    { name: 'Vitamin D3 + K2', timing: 'Morning with meal', dose: 'D3: 2000IU + K2: 100mcg', reason: 'Bone density, testosterone, immunity' },
    { name: 'Magnesium Glycinate', timing: 'Before bed', dose: '400mg', reason: 'Sleep quality, muscle recovery, stress' },
    { name: 'Omega-3 (Algae-based)', timing: 'With dinner', dose: '1000mg DHA+EPA', reason: 'Anti-inflammatory, brain health, hair' },
    { name: 'Zinc + Copper', timing: 'Morning', dose: 'Zn 15mg + Cu 1mg', reason: 'Testosterone, hair growth, immune system' },
    { name: 'Ashwagandha (KSM-66)', timing: 'Night with milk', dose: '600mg', reason: 'Cortisol reduction, testosterone boost, confidence' },
    { name: 'Vitamin B-Complex', timing: 'Morning', dose: '1 tablet', reason: 'Energy, hair growth, nerve health' },
    { name: 'Biotin', timing: 'Morning with food', dose: '5000–10000 mcg', reason: 'Hair regrowth, skin, nails' },
  ];

  const caloriePlan = [
    { phase: 'Month 1–3', calories: '1800–2000', protein: '150g', carbs: '180g', fat: '55g', goal: 'Fat loss priority' },
    { phase: 'Month 4–9', calories: '2000–2200', protein: '160g', carbs: '200g', fat: '65g', goal: 'Fat loss + muscle gain' },
    { phase: 'Month 10–18', calories: '2200–2500', protein: '170g', carbs: '220g', fat: '70g', goal: 'Recomposition' },
    { phase: 'Month 19–24', calories: '2400–2600', protein: '180g', carbs: '240g', fat: '75g', goal: 'Muscle building' },
  ];

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🥗</span>
          <h2 className="text-3xl font-black text-white">Vegetarian Diet Plan</h2>
        </div>
        <p className="text-gray-400 ml-14">100% Pure Vegetarian — High Protein — Designed for 120kg → 70kg Transformation</p>
      </div>

      {/* Calorie Targets */}
      <Card className="border-orange-500/30">
        <h3 className="text-xl font-bold text-orange-400 mb-4 flex items-center gap-2">
          📊 Calorie & Macro Targets by Phase
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left text-gray-400 py-2 pr-4">Phase</th>
                <th className="text-left text-gray-400 py-2 pr-4">Calories</th>
                <th className="text-left text-gray-400 py-2 pr-4">Protein</th>
                <th className="text-left text-gray-400 py-2 pr-4">Carbs</th>
                <th className="text-left text-gray-400 py-2 pr-4">Fat</th>
                <th className="text-left text-gray-400 py-2">Goal</th>
              </tr>
            </thead>
            <tbody>
              {caloriePlan.map((row) => (
                <tr key={row.phase} className="border-b border-gray-800">
                  <td className="py-3 pr-4 text-white font-semibold">{row.phase}</td>
                  <td className="py-3 pr-4 text-green-400 font-bold">{row.calories}</td>
                  <td className="py-3 pr-4 text-blue-400">{row.protein}</td>
                  <td className="py-3 pr-4 text-yellow-400">{row.carbs}</td>
                  <td className="py-3 pr-4 text-purple-400">{row.fat}</td>
                  <td className="py-3 text-gray-300 text-xs">{row.goal}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-gray-500 text-xs mt-3">* Your current TDEE at 120kg sedentary ≈ 2800–3000 cal. Creating a 700–1000 cal deficit = 0.7–1 kg/week fat loss safely.</p>
      </Card>

      {/* Daily Meal Plan */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          🍽️ Complete Daily Meal Plan
        </h3>
        <div className="space-y-4">
          {mealPlan.map((meal) => (
            <Card key={meal.time} className={meal.color}>
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <span className="text-orange-400 font-mono font-bold text-sm bg-orange-500/10 px-3 py-1 rounded-lg">
                  {meal.time}
                </span>
                <h4 className="text-white font-bold text-lg">{meal.meal}</h4>
              </div>
              <ul className="space-y-1 mb-3">
                {meal.items.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-gray-300 text-sm">
                    <span className="text-green-400 mt-0.5 flex-shrink-0">→</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <div className="flex flex-wrap gap-3">
                <div className={`${meal.badge} text-xs font-mono px-3 py-1 rounded-lg`}>
                  📊 {meal.macros}
                </div>
                <div className="bg-gray-700/40 text-gray-400 text-xs px-3 py-1 rounded-lg">
                  ✨ {meal.benefits}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Total Daily Summary */}
      <Card className="border-green-500/30 bg-green-900/10">
        <h3 className="text-xl font-bold text-green-400 mb-4">📈 Daily Totals Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Calories', value: '~2100', sub: 'Creating deficit', color: 'text-green-400' },
            { label: 'Total Protein', value: '~197g', sub: '1.6g/kg bodyweight', color: 'text-blue-400' },
            { label: 'Total Carbs', value: '~367g', sub: 'Complex carbs only', color: 'text-yellow-400' },
            { label: 'Total Fat', value: '~94g', sub: 'Healthy fats', color: 'text-purple-400' },
          ].map((stat) => (
            <div key={stat.label} className="bg-gray-800/50 rounded-xl p-4 text-center">
              <div className={`text-2xl font-black ${stat.color}`}>{stat.value}</div>
              <div className="text-white text-sm font-semibold mt-1">{stat.label}</div>
              <div className="text-gray-500 text-xs">{stat.sub}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Protein Sources */}
      <Card className="border-blue-500/30">
        <h3 className="text-xl font-bold text-blue-400 mb-4">🥩 Best Vegetarian Protein Sources</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left text-gray-400 py-2 pr-4">Food</th>
                <th className="text-left text-gray-400 py-2 pr-4">Protein</th>
                <th className="text-left text-gray-400 py-2">Benefits</th>
              </tr>
            </thead>
            <tbody>
              {proteinSources.map((src) => (
                <tr key={src.food} className="border-b border-gray-800">
                  <td className="py-3 pr-4 text-white font-medium">{src.food}</td>
                  <td className="py-3 pr-4 text-green-400 font-bold">
                    {src.per100g || src.perscoop || src.per100ml}
                  </td>
                  <td className="py-3 text-gray-400 text-xs">{src.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Supplements */}
      <Card className="border-purple-500/30">
        <h3 className="text-xl font-bold text-purple-400 mb-4">💊 Supplement Stack (Diet Support)</h3>
        <div className="grid gap-3">
          {supplements.map((supp) => (
            <div key={supp.name} className="bg-gray-700/30 rounded-xl p-4 flex flex-wrap gap-4 items-start">
              <div className="flex-1 min-w-48">
                <div className="text-white font-bold text-sm">{supp.name}</div>
                <div className="text-gray-400 text-xs mt-1">{supp.reason}</div>
              </div>
              <div className="flex gap-3 flex-wrap">
                <span className="bg-purple-500/20 text-purple-300 text-xs px-3 py-1 rounded-lg">{supp.dose}</span>
                <span className="bg-gray-600/40 text-gray-400 text-xs px-3 py-1 rounded-lg">{supp.timing}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Foods to AVOID */}
      <Card className="border-red-500/30 bg-red-900/10">
        <h3 className="text-xl font-bold text-red-400 mb-4">🚫 Foods to ELIMINATE Completely</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {[
            '❌ Sugar & sweets (maida mithai, cakes, biscuits)',
            '❌ White rice in large quantities (replace with brown rice/quinoa)',
            '❌ Fried foods (samosa, puri, pakora)',
            '❌ Refined flour (maida) — roti, bread, naan',
            '❌ Soft drinks, packaged juices (pure sugar bombs)',
            '❌ Alcohol & tobacco (destroys testosterone)',
            '❌ Trans fats (vanaspati, dalda, packaged snacks)',
            '❌ Excessive salt (causes water retention, bloating)',
            '❌ Late-night heavy meals (fat storage peak)',
            '❌ Skipping meals (slows metabolism by 20–30%)',
          ].map((item) => (
            <div key={item} className="bg-red-900/20 rounded-xl p-3 text-sm text-red-200">
              {item}
            </div>
          ))}
        </div>
      </Card>

      {/* Water Protocol */}
      <Card className="border-cyan-500/30">
        <h3 className="text-xl font-bold text-cyan-400 mb-4">💧 Water & Hydration Protocol</h3>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { title: 'Daily Target', desc: '4–5 liters of water per day. More on workout days.', icon: '💧' },
            { title: 'Morning Protocol', desc: '500ml warm water immediately on waking. Flushes toxins, boosts metabolism 30%.', icon: '☀️' },
            { title: 'Skin & Collagen', desc: 'Add 1 glass coconut water daily — rich in electrolytes and skin hydration.', icon: '🥥' },
          ].map((item) => (
            <div key={item.title} className="bg-cyan-900/20 border border-cyan-700/30 rounded-xl p-4">
              <div className="text-2xl mb-2">{item.icon}</div>
              <div className="text-cyan-300 font-bold mb-1">{item.title}</div>
              <div className="text-gray-400 text-sm">{item.desc}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
