interface NavigationProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const navItems = [
  { id: 'physical', label: 'Exercise', icon: '💪' },
  { id: 'diet', label: 'Diet', icon: '🥗' },
  { id: 'mental', label: 'Mental', icon: '🧠' },
  { id: 'medical', label: 'Medical', icon: '💊' },
  { id: 'hair', label: 'Hair', icon: '🦱' },
  { id: 'voice', label: 'Voice', icon: '🎙️' },
  { id: 'posture', label: 'Posture', icon: '🧍' },
  { id: 'roadmap', label: 'Roadmap', icon: '🗺️' },
];

export default function Navigation({ activeSection, setActiveSection }: NavigationProps) {
  return (
    <div className="sticky top-0 z-50 bg-gray-950/95 backdrop-blur-sm border-b border-gray-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex overflow-x-auto gap-1 py-3 scrollbar-hide">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 ${
                activeSection === item.id
                  ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
