export default function HeroSection() {
  return (
    <div
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        backgroundImage: 'url(/images/hero-bg.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-gray-950" />

      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-orange-500/20 border border-orange-500/40 rounded-full px-5 py-2 mb-6">
          <span className="text-orange-400 text-sm font-semibold tracking-widest uppercase">🔥 Your 2-Year Transformation Blueprint</span>
        </div>

        <h1 className="text-5xl md:text-7xl font-black mb-4 leading-tight">
          <span className="text-white">IRON </span>
          <span className="bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent">MAN</span>
          <br />
          <span className="text-white">PROTOCOL</span>
        </h1>

        <p className="text-xl md:text-2xl text-gray-300 mb-4 font-light">
          From <span className="text-red-400 font-bold">120kg</span> to{' '}
          <span className="text-green-400 font-bold">70kg Elite Calisthenics Athlete</span>
        </p>

        <p className="text-gray-400 text-lg mb-8 max-w-3xl mx-auto">
          A complete science-backed transformation plan covering physical training, vegetarian diet,
          mental health, medical protocol, hair restoration, voice deepening & posture correction.
          Built specifically for <strong className="text-white">YOU</strong>.
        </p>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto mb-10">
          {[
            { label: 'Current Weight', value: '120 kg', color: 'text-red-400' },
            { label: 'Target Weight', value: '70 kg', color: 'text-green-400' },
            { label: 'Timeline', value: '2 Years', color: 'text-orange-400' },
            { label: 'Goal', value: 'Elite Body', color: 'text-blue-400' },
          ].map((stat) => (
            <div key={stat.label} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4">
              <div className={`text-2xl font-black ${stat.color}`}>{stat.value}</div>
              <div className="text-gray-400 text-sm mt-1">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap gap-3 justify-center">
          {['💪 Calisthenics', '🥗 Vegetarian Diet', '🧠 Mental Strength', '💊 Medical Plan', '🦱 Hair Regrowth', '🎙️ Deep Voice'].map((tag) => (
            <span key={tag} className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-sm text-gray-300">
              {tag}
            </span>
          ))}
        </div>

        <div className="mt-12 animate-bounce">
          <div className="text-gray-500 text-sm">↓ Scroll to Begin Your Journey</div>
        </div>
      </div>
    </div>
  );
}
