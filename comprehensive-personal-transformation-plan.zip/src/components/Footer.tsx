export default function Footer() {
  return (
    <footer className="bg-gray-950 border-t border-gray-800 mt-16 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Quick Summary */}
        <div className="grid md:grid-cols-4 gap-6 mb-10">
          {[
            {
              icon: '💪',
              title: 'Physical Plan',
              points: ['4-Phase Calisthenics', 'Weekly HIIT Cardio', 'Bone Strengthening', 'Post-Surgery Safe'],
            },
            {
              icon: '🥗',
              title: 'Diet Plan',
              points: ['100% Vegetarian', '150–180g Protein/day', 'Calorie Deficit', 'Supplement Stack'],
            },
            {
              icon: '🧠',
              title: 'Mental Plan',
              points: ['Stoic Philosophy', 'Confidence Protocol', 'Stress Management', 'Self-Defense'],
            },
            {
              icon: '🗺️',
              title: 'Medical & More',
              points: ['Blood Tests First', 'Hair Regrowth Plan', 'Voice Deepening', 'Posture Correction'],
            },
          ].map((section) => (
            <div key={section.title}>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">{section.icon}</span>
                <h4 className="text-white font-bold">{section.title}</h4>
              </div>
              <ul className="space-y-1">
                {section.points.map((p) => (
                  <li key={p} className="text-gray-500 text-sm flex items-center gap-2">
                    <span className="text-orange-400 text-xs">→</span>
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="bg-gray-900 rounded-2xl p-6 mb-8">
          <h4 className="text-red-400 font-bold mb-3 flex items-center gap-2">
            <span>⚕️</span> Medical Disclaimer
          </h4>
          <p className="text-gray-500 text-sm leading-relaxed">
            This plan is an educational and motivational guide based on scientific research and general health principles. It does NOT replace professional medical advice. Always consult with qualified healthcare professionals — including your physician, endocrinologist, dermatologist, physiotherapist, and surgeon — before starting any new exercise regimen, supplement protocol, or medication. Individual results vary. The supplement and medication suggestions here are informational only and require professional prescription where noted. Your gynecomastia surgery recovery protocol must be specifically managed by your operating surgeon. This plan was created to inspire and educate — your health professionals will personalize it for your specific needs.
          </p>
        </div>

        {/* Bottom */}
        <div className="text-center">
          <div className="text-3xl font-black text-white mb-2">
            IRON MAN <span className="text-orange-400">PROTOCOL</span>
          </div>
          <p className="text-gray-600 text-sm">
            Your 2-Year Blueprint to Becoming the Most Powerful Version of Yourself
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-4 text-gray-700 text-xs">
            <span>120kg → 70kg</span>
            <span>•</span>
            <span>Calisthenics Athlete</span>
            <span>•</span>
            <span>Six Pack</span>
            <span>•</span>
            <span>Hair Regrowth</span>
            <span>•</span>
            <span>Deep Voice</span>
            <span>•</span>
            <span>Iron Mind</span>
            <span>•</span>
            <span>100+ Year Life</span>
          </div>
          <div className="mt-6 text-orange-500 text-lg font-bold">
            "The pain you feel today will be the strength you feel tomorrow." ⚡
          </div>
        </div>
      </div>
    </footer>
  );
}
