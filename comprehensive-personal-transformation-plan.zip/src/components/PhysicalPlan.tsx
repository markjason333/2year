function SectionTitle({ icon, title, subtitle }: { icon: string; title: string; subtitle: string }) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-2">
        <span className="text-4xl">{icon}</span>
        <h2 className="text-3xl font-black text-white">{title}</h2>
      </div>
      <p className="text-gray-400 ml-14">{subtitle}</p>
    </div>
  );
}

function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function PhysicalPlan() {
  const phases = [
    {
      phase: 'PHASE 1',
      duration: 'Months 1–3: Foundation',
      color: 'from-blue-600 to-blue-800',
      border: 'border-blue-500/30',
      badge: 'bg-blue-500/20 text-blue-300',
      note: '⚠️ Post-Surgery Phase: No chest exercises until surgeon clears you (typically 6–8 weeks post-op)',
      days: [
        {
          day: 'Day 1 – Upper Body A (No Chest)',
          exercises: [
            { name: 'Wall Push-Ups', sets: '3×15', note: 'Arm strength only' },
            { name: 'Band Pull-Aparts', sets: '3×20', note: 'Posture fix' },
            { name: 'Hanging from Bar (Dead Hang)', sets: '3×20 sec', note: 'Grip + decompression' },
            { name: 'Doorframe Rows', sets: '3×10', note: 'Back activation' },
            { name: 'Bicep Curls (Water Bottle)', sets: '3×12', note: 'Thin arm fix' },
          ],
        },
        {
          day: 'Day 2 – Lower Body + Core',
          exercises: [
            { name: 'Bodyweight Squats', sets: '4×20', note: 'Glute activation' },
            { name: 'Glute Bridges', sets: '3×20', note: 'Pelvic tilt correction' },
            { name: 'Reverse Lunges', sets: '3×12 each', note: 'Balance + leg strength' },
            { name: 'Calf Raises', sets: '3×25', note: 'Lower leg development' },
            { name: 'Plank Hold', sets: '3×30 sec', note: 'Core foundation' },
          ],
        },
        {
          day: 'Day 3 – Active Recovery + Cardio',
          exercises: [
            { name: 'Brisk Walk', sets: '30–45 mins', note: 'Fat burn zone' },
            { name: 'Neck Stretches (4 directions)', sets: '3×30 sec each', note: 'Neck pain relief' },
            { name: 'Cat-Cow Stretch', sets: '3×10', note: 'Spine mobility' },
            { name: 'Diaphragm Breathing', sets: '5 mins', note: 'Stress relief + voice training' },
          ],
        },
        {
          day: 'Day 4 – REST',
          exercises: [
            { name: 'Full Rest or Light Yoga', sets: '20 mins', note: 'Recovery is growth' },
          ],
        },
      ],
    },
    {
      phase: 'PHASE 2',
      duration: 'Months 4–9: Build & Burn',
      color: 'from-orange-600 to-orange-800',
      border: 'border-orange-500/30',
      badge: 'bg-orange-500/20 text-orange-300',
      note: '✅ Now add chest exercises. Weight loss target: 1–1.5 kg/week. Calisthenics progression begins.',
      days: [
        {
          day: 'Day 1 – Push (Chest/Shoulders/Triceps)',
          exercises: [
            { name: 'Standard Push-Ups', sets: '4×15→25', note: 'Progress each week' },
            { name: 'Wide Push-Ups', sets: '3×12', note: 'Outer chest' },
            { name: 'Tricep Dips (Chair)', sets: '3×12', note: 'Arm definition' },
            { name: 'Pike Push-Ups', sets: '3×10', note: 'Shoulder builder' },
            { name: 'Diamond Push-Ups', sets: '3×10', note: 'Inner chest + triceps' },
          ],
        },
        {
          day: 'Day 2 – Pull (Back/Biceps)',
          exercises: [
            { name: 'Australian Pull-Ups (Rows)', sets: '4×12', note: 'Back thickness' },
            { name: 'Negative Pull-Ups', sets: '3×5', note: 'Building to full pull-up' },
            { name: 'Assisted Pull-Ups', sets: '3×8', note: 'With band or chair' },
            { name: 'Chin-Ups', sets: '3×5→10', note: 'Bicep focus' },
            { name: 'Face Pulls (Band)', sets: '3×15', note: 'Rear delt + posture' },
          ],
        },
        {
          day: 'Day 3 – Legs + Core',
          exercises: [
            { name: 'Jump Squats', sets: '4×15', note: 'Explosive power' },
            { name: 'Bulgarian Split Squats', sets: '3×10 each', note: 'Leg mass' },
            { name: 'Wall Sit', sets: '3×45 sec', note: 'Quad endurance' },
            { name: 'Leg Raises (Lying)', sets: '4×15', note: 'Lower abs' },
            { name: 'Bicycle Crunches', sets: '3×20', note: 'Obliques' },
            { name: 'Mountain Climbers', sets: '3×30 sec', note: 'Core + cardio' },
          ],
        },
        {
          day: 'Day 4 – HIIT Cardio',
          exercises: [
            { name: 'Jump Rope', sets: '3×3 mins', note: 'Fat burner #1' },
            { name: 'Burpees', sets: '4×10', note: 'Full body blast' },
            { name: 'High Knees', sets: '4×30 sec', note: 'Heart rate spike' },
            { name: 'Box Jumps', sets: '3×10', note: 'Explosive legs' },
          ],
        },
      ],
    },
    {
      phase: 'PHASE 3',
      duration: 'Months 10–18: Athlete Mode',
      color: 'from-purple-600 to-purple-800',
      border: 'border-purple-500/30',
      badge: 'bg-purple-500/20 text-purple-300',
      note: '🔥 Target weight ~80–85kg. True calisthenics skills begin. Six-pack becoming visible.',
      days: [
        {
          day: 'Day 1 – Advanced Push',
          exercises: [
            { name: 'Archer Push-Ups', sets: '4×10 each', note: 'One-arm prep' },
            { name: 'Pseudo Planche Push-Ups', sets: '3×8', note: 'Planche foundation' },
            { name: 'Handstand Practice (Wall)', sets: '5×30 sec', note: 'Balance + strength' },
            { name: 'Ring Dips (or Deep Dips)', sets: '4×10', note: 'Chest + triceps' },
            { name: 'Pike Push-Up to Handstand', sets: '3×5', note: 'Shoulder power' },
          ],
        },
        {
          day: 'Day 2 – Advanced Pull',
          exercises: [
            { name: 'Full Pull-Ups', sets: '5×10+', note: 'Core goal achieved' },
            { name: 'L-Sit Pull-Ups', sets: '3×5', note: 'Core + pull combo' },
            { name: 'Typewriter Pull-Ups', sets: '3×5 each', note: 'Advanced back' },
            { name: 'Muscle-Up Practice', sets: '3×3', note: 'Elite skill' },
            { name: 'Front Lever Tuck Hold', sets: '3×10 sec', note: 'Core power' },
          ],
        },
        {
          day: 'Day 3 – Legs + Core Elite',
          exercises: [
            { name: 'Pistol Squat Practice', sets: '3×5 each', note: 'Single leg mastery' },
            { name: 'Nordic Curls', sets: '3×8', note: 'Hamstring iron' },
            { name: 'Dragon Flag Progression', sets: '3×5', note: 'Bruce Lee core' },
            { name: 'V-Sit Hold', sets: '3×15 sec', note: 'Core compression' },
            { name: 'Hollow Body Hold', sets: '3×30 sec', note: 'Gymnast core' },
          ],
        },
      ],
    },
    {
      phase: 'PHASE 4',
      duration: 'Months 19–24: IRON MAN',
      color: 'from-red-600 to-red-800',
      border: 'border-red-500/30',
      badge: 'bg-red-500/20 text-red-300',
      note: '🏆 Target weight ~70–72kg. Full calisthenics athlete physique. Visible six-pack. Iron constitution.',
      days: [
        {
          day: 'Skills to Master',
          exercises: [
            { name: 'Muscle-Ups (Strict)', sets: '5×5', note: 'Elite upper body' },
            { name: 'Handstand Push-Ups', sets: '4×8', note: 'Iron shoulders' },
            { name: 'One-Arm Push-Up', sets: '3×5 each', note: 'True strength' },
            { name: 'Front Lever (Full)', sets: '3×10 sec', note: 'Superhero core' },
            { name: 'Human Flag Tuck', sets: '3×5 sec', note: 'Iron body' },
            { name: 'Pistol Squats', sets: '4×10 each', note: 'Legs of steel' },
          ],
        },
      ],
    },
  ];

  const dailyRoutine = [
    { time: '5:30 AM', activity: 'Wake Up + Cold Water (500ml) + Morning Sunlight 10 mins', icon: '☀️' },
    { time: '5:45 AM', activity: 'Diaphragm Breathing + Voice Exercises (10 mins)', icon: '🌬️' },
    { time: '6:00 AM', activity: 'Workout (60–75 minutes)', icon: '💪' },
    { time: '7:30 AM', activity: 'Post-Workout Protein Meal + Shower', icon: '🍳' },
    { time: '8:30 AM', activity: 'Work (Set hourly standing/stretch reminders)', icon: '💼' },
    { time: '1:00 PM', activity: 'Lunch + 5-minute walking break', icon: '🥗' },
    { time: '4:00 PM', activity: 'Healthy Snack + Neck Exercises at desk', icon: '🥜' },
    { time: '7:00 PM', activity: 'Evening Walk (30 mins) or Stretching', icon: '🚶' },
    { time: '8:00 PM', activity: 'Dinner', icon: '🍛' },
    { time: '9:30 PM', activity: 'Journaling + Reading (Stoic/Self-help)', icon: '📖' },
    { time: '10:00 PM', activity: 'No Phone. Deep Sleep Protocol Begins', icon: '😴' },
    { time: '10:30 PM', activity: 'Lights Out — 7.5 hrs sleep (Growth Hormone Peak)', icon: '🌙' },
  ];

  return (
    <div className="space-y-8">
      <SectionTitle
        icon="💪"
        title="Physical Training Plan"
        subtitle="Professional Calisthenics Athlete Protocol — 4 Progressive Phases over 24 Months"
      />

      {/* Daily Schedule */}
      <Card className="border-orange-500/30">
        <h3 className="text-xl font-bold text-orange-400 mb-5 flex items-center gap-2">
          ⏰ Your Ideal Daily Schedule
        </h3>
        <div className="grid gap-2">
          {dailyRoutine.map((item) => (
            <div key={item.time} className="flex items-center gap-4 bg-gray-700/30 rounded-xl p-3">
              <div className="text-orange-400 font-mono text-sm font-bold w-20 flex-shrink-0">{item.time}</div>
              <span className="text-xl">{item.icon}</span>
              <span className="text-gray-300 text-sm">{item.activity}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Training Phases */}
      {phases.map((phase) => (
        <Card key={phase.phase} className={phase.border}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`bg-gradient-to-r ${phase.color} text-white text-xs font-black px-3 py-1 rounded-full`}>
              {phase.phase}
            </div>
            <h3 className="text-white font-bold text-xl">{phase.duration}</h3>
          </div>

          <div className={`${phase.badge} rounded-xl p-3 mb-5 text-sm font-medium`}>
            {phase.note}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {phase.days.map((dayPlan) => (
              <div key={dayPlan.day} className="bg-gray-700/30 rounded-xl p-4">
                <h4 className="text-white font-bold text-sm mb-3 pb-2 border-b border-gray-600">
                  {dayPlan.day}
                </h4>
                <div className="space-y-2">
                  {dayPlan.exercises.map((ex) => (
                    <div key={ex.name} className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <span className="text-gray-200 text-sm font-medium">{ex.name}</span>
                        <span className="text-gray-500 text-xs block">{ex.note}</span>
                      </div>
                      <span className="text-orange-400 text-xs font-bold bg-orange-500/10 px-2 py-1 rounded-lg flex-shrink-0">
                        {ex.sets}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}

      {/* Cardio Plan */}
      <Card className="border-green-500/30">
        <h3 className="text-xl font-bold text-green-400 mb-4 flex items-center gap-2">
          🏃 Weekly Cardio & Fat Loss Protocol
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            {
              type: 'Months 1–3',
              desc: 'Brisk Walking 30–45 min daily. Target heart rate: 100–120 BPM. This alone burns 300–400 cal/session.',
              color: 'border-blue-500/40 bg-blue-900/10',
            },
            {
              type: 'Months 4–9',
              desc: 'Add 3x/week HIIT: 20-min sessions. Jump rope, burpees, high knees. Burns 400–600 cal/session.',
              color: 'border-orange-500/40 bg-orange-900/10',
            },
            {
              type: 'Months 10–24',
              desc: 'Steady-state jog 5km + HIIT 2x/week. Parkour/outdoor calisthenics. Keep body-fat below 12%.',
              color: 'border-green-500/40 bg-green-900/10',
            },
          ].map((c) => (
            <div key={c.type} className={`rounded-xl p-4 border ${c.color}`}>
              <div className="text-white font-bold mb-2">{c.type}</div>
              <div className="text-gray-400 text-sm">{c.desc}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-yellow-900/20 border border-yellow-700/30 rounded-xl p-4">
          <p className="text-yellow-300 text-sm">
            <strong>🔑 Key Rule:</strong> Your goal is to lose ~50 kg of fat while gaining ~10–15 kg of lean muscle. This takes 18–24 months with consistency. Never crash diet — aim for 500–700 calorie daily deficit maximum. Faster fat loss = muscle loss = weaker body.
          </p>
        </div>
      </Card>

      {/* Bone Strength */}
      <Card className="border-gray-500/30">
        <h3 className="text-xl font-bold text-white mb-4">🦴 Bone Density & Strength Protocol</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h4 className="text-orange-400 font-semibold mb-3">Bone-Strengthening Exercises</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              {[
                'Jump Rope — impact loads bones (femur, tibia)',
                'Weighted Squats progression (bodyweight first)',
                'Dead Hangs — decompress spine, strengthen forearms',
                'Pull-Ups — massive bone density in upper body',
                'Running/Jogging — natural bone loading',
                'Handstands — wrist + shoulder bone density',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-green-400 mt-1">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-orange-400 font-semibold mb-3">Nutrition for Bones</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              {[
                'Calcium: 1000–1200mg/day (milk, paneer, sesame)',
                'Vitamin D3: 2000–4000 IU daily (supplement + sunlight)',
                'Vitamin K2: MK-7 form (helps calcium go to bones)',
                'Magnesium: 400mg/day (dark leafy greens, seeds)',
                'Boron: Traces in fruits & vegetables',
                'Phosphorus: Legumes, dairy, nuts',
              ].map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <span className="text-blue-400 mt-1">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
