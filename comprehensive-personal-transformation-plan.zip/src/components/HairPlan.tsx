function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function HairPlan() {
  const medicalTreatments = [
    {
      treatment: 'Minoxidil 5% (Topical)',
      effectiveness: '80–85%',
      howToUse: 'Apply 1ml to dry scalp 2x daily (morning + night). Use dropper to target thinning areas. Leave on — do NOT rinse.',
      timeline: 'See results in 3–6 months. Full results at 12 months.',
      type: 'OTC — Available without prescription',
      brand: 'Rogaine, Mintop, Tugain (India)',
      color: 'border-green-500/40 bg-green-900/10',
      badge: '✅ Gold Standard — Start This TODAY',
    },
    {
      treatment: 'Finasteride 1mg (Oral)',
      effectiveness: '90%+ at stopping progression',
      howToUse: 'One tablet daily with or without food. Take at same time daily for consistency.',
      timeline: 'Stops further loss within 1–3 months. Regrowth visible at 6–12 months.',
      type: '⚠️ REQUIRES doctor prescription — consult dermatologist',
      brand: 'Finpecia, Propecia',
      color: 'border-blue-500/40 bg-blue-900/10',
      badge: '⚕️ Most Effective DHT Blocker',
    },
    {
      treatment: 'Ketoconazole Shampoo 2%',
      effectiveness: '50–60% (supportive)',
      howToUse: 'Use 3x per week. Lather, leave on scalp 3–5 mins before rinsing. Reduces DHT at scalp.',
      timeline: 'Supportive treatment — use alongside Minoxidil.',
      type: 'Prescription strength — OTC 1% versions available',
      brand: 'Nizoral, Ketomac',
      color: 'border-purple-500/40 bg-purple-900/10',
      badge: '💆 Anti-DHT Scalp Treatment',
    },
    {
      treatment: 'PRP Therapy (Platelet Rich Plasma)',
      effectiveness: '60–75%',
      howToUse: 'Your own blood is processed and injected into scalp. Dermatologist procedure. 3 sessions, 1 month apart.',
      timeline: 'Results visible at 3–6 months post-treatment.',
      type: '🏥 Clinic procedure — consult dermatologist',
      brand: 'Available at most dermatology clinics in India',
      color: 'border-orange-500/40 bg-orange-900/10',
      badge: '🩸 Advanced Regenerative Therapy',
    },
  ];

  const supplements = [
    { name: 'Biotin (B7)', dose: '5000–10,000 mcg/day', role: 'Keratin production — essential for hair, skin, nails' },
    { name: 'Zinc Picolinate', dose: '15–30mg/day', role: 'DHT regulation, follicle repair, tissue growth' },
    { name: 'Iron (Ferritin)', dose: 'Based on blood test', role: 'Iron deficiency = #1 cause of hair loss in Indians' },
    { name: 'Vitamin D3', dose: '2000–5000 IU/day', role: 'Follicle cycling — deficiency directly causes hair loss' },
    { name: 'Vitamin B12', dose: '1000mcg (methylcobalamin)', role: 'Vegetarians critical — nerve + hair health' },
    { name: 'Saw Palmetto', dose: '320mg/day', role: 'Natural DHT blocker — supports finasteride' },
    { name: 'Omega-3 (Algae DHA/EPA)', dose: '1000mg/day', role: 'Scalp inflammation reduction — improves follicle health' },
    { name: 'Collagen Peptides', dose: '10g/day', role: 'Scalp skin elasticity, hair shaft strength' },
    { name: 'Pumpkin Seed Oil', dose: '1000mg/day', role: 'Clinically studied DHT inhibitor. 40% improvement in trials.' },
    { name: 'Vitamin E', dose: '400 IU/day', role: 'Antioxidant protection for follicles, scalp circulation' },
  ];

  const hairCareRoutine = [
    {
      step: 'Wash Hair',
      freq: '3x per week max',
      method: 'Use ketoconazole shampoo 3x/week. Regular days: use sulfate-free gentle shampoo. Never rub hair aggressively — pat dry only.',
    },
    {
      step: 'Scalp Massage',
      freq: 'Daily — 4–5 minutes',
      method: 'With fingertips (not nails). Increases blood flow to follicles by 25%. Apply rosemary oil during massage (as effective as 2% minoxidil in studies).',
    },
    {
      step: 'Rosemary Oil Treatment',
      freq: '3x per week',
      method: 'Mix 5 drops rosemary essential oil in 1 tsp coconut oil. Massage into scalp. Leave for 30–60 minutes. Rinse. Clinically proven to match minoxidil efficacy.',
    },
    {
      step: 'Minoxidil Application',
      freq: 'Twice daily',
      method: 'Morning: after shower on DRY scalp. Night: before bed. Wait 4 hours before washing after application.',
    },
    {
      step: 'Protect from Heat/Sun',
      freq: 'Daily',
      method: 'UV radiation damages hair shafts and scalp. Wear cap during outdoor sun exposure. Never use heat tools on already weakened hair.',
    },
  ];

  const dietForHair = [
    { food: 'Pumpkin seeds', nutrient: 'Zinc + Pumpkin seed oil', portion: '30g daily' },
    { food: 'Sesame seeds (til)', nutrient: 'Calcium + Iron + Zinc', portion: '2 tbsp daily' },
    { food: 'Amla (Indian Gooseberry)', nutrient: 'Vitamin C + antioxidants', portion: '1 fresh or 1 tsp powder' },
    { food: 'Walnuts', nutrient: 'Omega-3, Biotin, Vitamin E', portion: '4–5 daily' },
    { food: 'Spinach (Palak)', nutrient: 'Iron + Folate', portion: '1 cup daily' },
    { food: 'Lentils (all dals)', nutrient: 'Iron + Protein + Zinc', portion: '1.5 cups daily' },
    { food: 'Sweet Potato', nutrient: 'Beta-carotene → Vitamin A', portion: '1 medium 3x/week' },
    { food: 'Greek Yogurt', nutrient: 'B5 (pantothenic acid)', portion: '1 cup daily' },
  ];

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">🦱</span>
          <h2 className="text-3xl font-black text-white">Hair Regrowth Plan</h2>
        </div>
        <p className="text-gray-400 ml-14">Science-backed protocol to stop hair fall, regrow hair, and maintain full healthy hair</p>
      </div>

      {/* Root Cause */}
      <Card className="border-yellow-500/30 bg-yellow-900/10">
        <h3 className="text-lg font-bold text-yellow-400 mb-3">🔬 Why You're Losing Hair — Root Causes</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {[
            { cause: 'DHT (Dihydrotestosterone)', desc: 'Primary driver of male pattern baldness. DHT miniaturizes follicles. Your high body fat may increase DHT conversion.' },
            { cause: 'Iron Deficiency', desc: 'Extremely common in vegetarians. Ferritin below 70 ng/mL causes significant hair shedding.' },
            { cause: 'Vitamin D Deficiency', desc: 'Directly affects follicle cycling. 80% of Indians are Vitamin D deficient.' },
            { cause: 'Zinc Deficiency', desc: 'Low zinc = disrupted keratin production + elevated DHT.' },
            { cause: 'High Cortisol (Stress)', desc: 'Chronic stress triggers telogen effluvium — massive hair shedding.' },
            { cause: 'Poor Scalp Circulation', desc: 'Sedentary lifestyle reduces blood flow to scalp. Exercise directly helps.' },
          ].map((item) => (
            <div key={item.cause} className="bg-yellow-900/20 rounded-xl p-3">
              <div className="text-yellow-300 font-bold text-sm">{item.cause}</div>
              <div className="text-gray-400 text-xs mt-1">{item.desc}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Medical Treatments */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4">💊 Clinically Proven Medical Treatments</h3>
        <div className="space-y-4">
          {medicalTreatments.map((treatment) => (
            <Card key={treatment.treatment} className={`border ${treatment.color}`}>
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                <div>
                  <h4 className="text-white font-black text-lg">{treatment.treatment}</h4>
                  <div className="text-green-400 text-sm font-semibold">Effectiveness: {treatment.effectiveness}</div>
                </div>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-gray-700 text-gray-300">{treatment.badge}</span>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <div className="text-gray-400 text-xs mb-1 font-semibold uppercase">How to Use</div>
                  <div className="text-gray-300 text-sm">{treatment.howToUse}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-xs mb-1 font-semibold uppercase">Timeline</div>
                  <div className="text-gray-300 text-sm">{treatment.timeline}</div>
                  <div className="mt-2 text-xs text-orange-400">{treatment.type}</div>
                  <div className="text-gray-500 text-xs mt-1">Brands: {treatment.brand}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Supplements */}
      <Card className="border-blue-500/30">
        <h3 className="text-xl font-bold text-blue-400 mb-4">💊 Hair Growth Supplement Stack</h3>
        <div className="grid gap-3">
          {supplements.map((supp) => (
            <div key={supp.name} className="bg-gray-700/30 rounded-xl p-3 flex flex-wrap gap-4 items-start">
              <div className="flex-1 min-w-40">
                <div className="text-white font-bold text-sm">{supp.name}</div>
                <div className="text-gray-400 text-xs mt-0.5">{supp.role}</div>
              </div>
              <span className="text-blue-300 text-xs bg-blue-500/10 px-3 py-1 rounded-lg">{supp.dose}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Hair Care Routine */}
      <Card className="border-purple-500/30">
        <h3 className="text-xl font-bold text-purple-400 mb-4">🪮 Daily Hair Care Routine</h3>
        <div className="space-y-4">
          {hairCareRoutine.map((item) => (
            <div key={item.step} className="bg-gray-700/30 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-bold">{item.step}</span>
                <span className="text-purple-400 text-xs bg-purple-500/20 px-3 py-1 rounded-full">{item.freq}</span>
              </div>
              <p className="text-gray-400 text-sm">{item.method}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Diet for Hair */}
      <Card className="border-green-500/30">
        <h3 className="text-xl font-bold text-green-400 mb-4">🥗 Foods That Grow Hair</h3>
        <div className="grid md:grid-cols-2 gap-3">
          {dietForHair.map((item) => (
            <div key={item.food} className="bg-gray-700/30 rounded-xl p-3 flex items-center gap-3">
              <span className="text-2xl">🌿</span>
              <div>
                <div className="text-white font-bold text-sm">{item.food}</div>
                <div className="text-green-400 text-xs">{item.nutrient}</div>
                <div className="text-gray-500 text-xs">{item.portion}</div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Timeline */}
      <Card className="border-orange-500/30">
        <h3 className="text-xl font-bold text-orange-400 mb-4">📅 Expected Hair Regrowth Timeline</h3>
        <div className="space-y-3">
          {[
            { period: 'Month 1–2', expectation: 'Hair fall INCREASES (this is normal — minoxidil shedding phase). Old weak hairs shed to make room for new, stronger ones. DO NOT STOP.', color: 'bg-red-900/20 border-red-700/30' },
            { period: 'Month 3–4', expectation: 'Shedding slows. First signs of new growth — thin baby hairs at temples and crown.', color: 'bg-yellow-900/20 border-yellow-700/30' },
            { period: 'Month 6', expectation: 'Visible improvement in hair density. Hairline stabilizes. New growth noticeable to others.', color: 'bg-blue-900/20 border-blue-700/30' },
            { period: 'Month 12', expectation: 'Significant regrowth. Hair density noticeably improved. Continue treatment — stopping causes reversal within 6 months.', color: 'bg-green-900/20 border-green-700/30' },
            { period: 'Month 24+', expectation: 'Maximum results achieved. Your hair is now as full as it will get. Maintenance phase — continue treatment indefinitely.', color: 'bg-purple-900/20 border-purple-700/30' },
          ].map((item) => (
            <div key={item.period} className={`border rounded-xl p-4 ${item.color}`}>
              <div className="text-white font-bold mb-1">{item.period}</div>
              <div className="text-gray-300 text-sm">{item.expectation}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
