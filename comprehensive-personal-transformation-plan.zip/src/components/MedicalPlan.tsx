function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-gray-800/60 border border-gray-700/50 rounded-2xl p-6 ${className}`}>
      {children}
    </div>
  );
}

export default function MedicalPlan() {
  const bloodTests = [
    { test: 'Complete Blood Count (CBC)', reason: 'Detect anemia, infections, immune function' },
    { test: 'Comprehensive Metabolic Panel', reason: 'Liver, kidney, glucose, electrolytes' },
    { test: 'Lipid Profile (Full)', reason: 'Cholesterol — at 120kg this is critical' },
    { test: 'HbA1c + Fasting Glucose', reason: 'Check for pre-diabetes (very likely at current weight)' },
    { test: 'Total & Free Testosterone', reason: 'Check hormone levels, plan voice/strength improvements' },
    { test: 'DHT (Dihydrotestosterone)', reason: 'Hair loss root cause — drives MPB' },
    { test: 'LH, FSH, Prolactin', reason: 'Post-gyno surgery hormonal check' },
    { test: 'Thyroid Panel (TSH, T3, T4)', reason: 'Thyroid issues cause weight gain, hair loss, energy problems' },
    { test: 'Vitamin D3 Level', reason: 'Deficiency = hair loss + bone weakness + depression' },
    { test: 'Vitamin B12', reason: 'Vegetarians are almost always deficient — critical for nerves, energy' },
    { test: 'Ferritin + Serum Iron', reason: 'Iron deficiency = hair loss, fatigue, thin arms' },
    { test: 'Zinc Level', reason: 'Low zinc = hair loss + low testosterone' },
    { test: 'Cortisol (Morning)', reason: 'Stress hormone — chronic elevation destroys everything' },
    { test: 'IGF-1', reason: 'Growth hormone marker — key for muscle building at your age' },
  ];

  const specialists = [
    {
      specialist: 'Endocrinologist',
      reason: 'Check testosterone, thyroid, insulin resistance, hormones post-gyno surgery',
      timing: 'Month 1 — PRIORITY',
      icon: '🧬',
      color: 'border-red-500/40 bg-red-900/10',
    },
    {
      specialist: 'Plastic Surgeon (Your Gyno Surgeon)',
      reason: 'Follow-up on gynecomastia surgery. Get cleared for chest exercises. Scar treatment.',
      timing: 'Every 6 weeks post-surgery',
      icon: '🏥',
      color: 'border-orange-500/40 bg-orange-900/10',
    },
    {
      specialist: 'Dietitian / Nutritionist',
      reason: 'Personalize calorie targets based on your actual metabolic rate and blood results',
      timing: 'Month 1',
      icon: '🥗',
      color: 'border-green-500/40 bg-green-900/10',
    },
    {
      specialist: 'Dermatologist',
      reason: 'Prescribe Minoxidil + Finasteride for hair loss. Check scalp health.',
      timing: 'Month 1 — PRIORITY',
      icon: '💆',
      color: 'border-blue-500/40 bg-blue-900/10',
    },
    {
      specialist: 'Physiotherapist',
      reason: 'Neck pain + anterior/posterior pelvic tilt correction. Custom exercise prescription.',
      timing: 'Month 1 — PRIORITY',
      icon: '🦴',
      color: 'border-purple-500/40 bg-purple-900/10',
    },
    {
      specialist: 'Ophthalmologist',
      reason: 'Annual eye check — sedentary screen work damages eyes.',
      timing: 'Month 3',
      icon: '👁️',
      color: 'border-cyan-500/40 bg-cyan-900/10',
    },
    {
      specialist: 'Cardiologist',
      reason: 'At 120kg with sedentary job — cardiac baseline is essential before intense exercise',
      timing: 'Month 1 — PRIORITY',
      icon: '❤️',
      color: 'border-pink-500/40 bg-pink-900/10',
    },
    {
      specialist: 'Psychologist / CBT Therapist',
      reason: 'Structured therapy for stress, emotional regulation, confidence, family issues',
      timing: 'Month 1 — STRONGLY RECOMMENDED',
      icon: '🧠',
      color: 'border-yellow-500/40 bg-yellow-900/10',
    },
  ];

  const gynSurgeryRecovery = [
    { week: 'Week 1–2', allowed: 'Rest, walking only, no arm movement', avoid: 'Any exercise, lifting, straining', care: 'Wear compression garment 24/7' },
    { week: 'Week 2–4', allowed: 'Light walking, bodyweight leg exercises, lower body work', avoid: 'Upper body, chest exercises', care: 'Continue compression vest. Start scar massage after week 3.' },
    { week: 'Week 4–6', allowed: 'Light cardio (stationary bike, walk), core planks', avoid: 'Push-ups, chest press, heavy upper body', care: 'Apply silicone gel on scars. Protect from sun.' },
    { week: 'Week 6+', allowed: 'Full return to exercise with surgeon clearance', avoid: 'Overtraining initially. Listen to body.', care: 'Monthly surgeon follow-up for 6 months.' },
  ];

  const coreSupplements = [
    { name: 'Vitamin D3 (5000 IU)', purpose: 'Bone health, testosterone, mood, immunity', when: 'Morning with fat meal' },
    { name: 'Vitamin K2 (MK-7, 200mcg)', purpose: 'Directs calcium to bones (not arteries)', when: 'With D3' },
    { name: 'Magnesium Glycinate (400mg)', purpose: 'Sleep quality, muscle function, stress hormones', when: 'Before bed' },
    { name: 'Vitamin B12 (1000mcg methylcobalamin)', purpose: 'CRITICAL for vegetarians — energy, nerves, red blood cells', when: 'Morning' },
    { name: 'Iron Bisglycinate (if ferritin low)', purpose: 'Fight anemia, hair loss, fatigue', when: 'With Vitamin C for absorption' },
    { name: 'Zinc Picolinate (15–30mg)', purpose: 'Testosterone, wound healing (post surgery), hair', when: 'With meal, not with iron' },
    { name: 'Omega-3 (Algae DHA/EPA 1000mg)', purpose: 'Anti-inflammation, joint health, brain, hair', when: 'With dinner' },
    { name: 'Ashwagandha KSM-66 (600mg)', purpose: 'Cortisol reduction, testosterone boost, recovery', when: 'Night' },
    { name: 'Creatine Monohydrate (5g)', purpose: 'Muscle strength, cognitive function, bone density', when: 'Post workout or anytime' },
    { name: 'Coenzyme Q10 (100mg)', purpose: 'Cellular energy, heart health, anti-aging', when: 'Morning with fat meal' },
  ];

  const longevityProtocol = [
    { habit: 'Sleep 7.5–8 hours (non-negotiable)', icon: '😴', impact: 'Growth hormone, testosterone, cortisol, immunity — ALL depend on sleep. This is your #1 anti-aging tool.' },
    { habit: 'Annual Full Health Checkup', icon: '🏥', impact: 'Catch metabolic diseases, cancer markers, organ function early. At your age + weight — do this NOW.' },
    { habit: 'No Smoking/Alcohol/Tobacco', icon: '🚭', impact: 'Each cigarette steals 11 minutes of life. Alcohol destroys testosterone, liver, and brain cells.' },
    { habit: 'Intermittent Fasting (optional 16:8)', icon: '⏰', impact: 'Activates autophagy (cellular repair). Reduces inflammation. Combines with your diet plan.' },
    { habit: 'Morning Sunlight 10 min daily', icon: '☀️', impact: 'Regulates circadian rhythm, Vitamin D production, serotonin synthesis, sleep quality.' },
    { habit: 'Oral Hygiene (twice daily)', icon: '🦷', impact: 'Gum disease linked to heart disease, cognitive decline. Poor oral health ages you 10 years faster.' },
    { habit: 'Social Connection', icon: '👥', impact: 'Loneliness is as deadly as smoking 15 cigarettes/day (Harvard longevity study). Build 2–3 deep friendships.' },
    { habit: 'Regular Physical Activity', icon: '🏃', impact: 'Exercise is the single most powerful longevity drug known to science. 150 min/week minimum.' },
  ];

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <span className="text-4xl">💊</span>
          <h2 className="text-3xl font-black text-white">Medical & Health Plan</h2>
        </div>
        <p className="text-gray-400 ml-14">Science-backed medical roadmap — from immediate priorities to 100-year longevity</p>
      </div>

      {/* Emergency Disclaimer */}
      <Card className="border-red-500/40 bg-red-900/10">
        <div className="flex items-start gap-3">
          <span className="text-3xl">⚕️</span>
          <div>
            <h3 className="text-red-400 font-bold text-lg mb-2">IMPORTANT: See These Doctors FIRST (Month 1)</h3>
            <p className="text-gray-300 text-sm">
              At 120kg with a sedentary lifestyle, you are at high risk for: Type 2 Diabetes, Hypertension, Sleep Apnea, High Cholesterol, and Fatty Liver. All of these are REVERSIBLE through your transformation plan, but you must GET TESTED first to know your baseline.
              <strong className="text-white"> Get blood tests before starting intense exercise. Always consult your physician.</strong>
            </p>
          </div>
        </div>
      </Card>

      {/* Blood Tests */}
      <Card className="border-blue-500/30">
        <h3 className="text-xl font-bold text-blue-400 mb-4 flex items-center gap-2">
          🩸 Essential Blood Tests — Get These NOW
        </h3>
        <div className="grid md:grid-cols-2 gap-3">
          {bloodTests.map((test) => (
            <div key={test.test} className="bg-gray-700/30 rounded-xl p-3">
              <div className="text-white font-medium text-sm">{test.test}</div>
              <div className="text-gray-400 text-xs mt-1">{test.reason}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Specialists */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4">👨‍⚕️ Medical Specialists to Visit</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {specialists.map((spec) => (
            <Card key={spec.specialist} className={`border ${spec.color}`}>
              <div className="flex items-start gap-3">
                <span className="text-3xl">{spec.icon}</span>
                <div>
                  <div className="text-white font-bold">{spec.specialist}</div>
                  <div className="text-gray-400 text-sm mt-1">{spec.reason}</div>
                  <div className="mt-2 bg-gray-700/50 text-orange-400 text-xs px-3 py-1 rounded-full inline-block">
                    ⏰ {spec.timing}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Gyno Surgery Recovery */}
      <Card className="border-purple-500/30">
        <h3 className="text-xl font-bold text-purple-400 mb-4 flex items-center gap-2">
          🏥 Gynecomastia Surgery Recovery Protocol
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left text-gray-400 py-2 pr-4">Timeline</th>
                <th className="text-left text-gray-400 py-2 pr-4">✅ Allowed</th>
                <th className="text-left text-gray-400 py-2 pr-4">🚫 Avoid</th>
                <th className="text-left text-gray-400 py-2">💊 Care</th>
              </tr>
            </thead>
            <tbody>
              {gynSurgeryRecovery.map((row) => (
                <tr key={row.week} className="border-b border-gray-800">
                  <td className="py-3 pr-4">
                    <span className="text-purple-400 font-bold bg-purple-500/20 px-2 py-1 rounded-lg text-xs">{row.week}</span>
                  </td>
                  <td className="py-3 pr-4 text-green-400 text-xs">{row.allowed}</td>
                  <td className="py-3 pr-4 text-red-400 text-xs">{row.avoid}</td>
                  <td className="py-3 text-gray-400 text-xs">{row.care}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4 bg-purple-900/20 rounded-xl p-4">
          <p className="text-purple-300 text-sm">
            <strong>Scar Treatment:</strong> Apply medical-grade silicone gel (Contractubex or Dermatix) 2x/day from week 3. After month 3, consider dermatologist-prescribed treatments. Protect scars from sun with SPF 50+. Full scar maturation takes 12–18 months.
          </p>
        </div>
      </Card>

      {/* Core Supplements */}
      <Card className="border-green-500/30">
        <h3 className="text-xl font-bold text-green-400 mb-4 flex items-center gap-2">
          💊 Core Supplement Protocol
        </h3>
        <p className="text-gray-400 text-sm mb-4">⚠️ Always consult doctor before starting supplements. Do blood tests first to identify deficiencies.</p>
        <div className="space-y-3">
          {coreSupplements.map((supp) => (
            <div key={supp.name} className="bg-gray-700/30 rounded-xl p-4 flex flex-wrap gap-4 items-start">
              <div className="flex-1 min-w-48">
                <div className="text-white font-bold text-sm">{supp.name}</div>
                <div className="text-gray-400 text-xs mt-1">{supp.purpose}</div>
              </div>
              <span className="text-green-400 text-xs bg-green-500/10 px-3 py-1 rounded-lg flex-shrink-0">{supp.when}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Longevity Protocol */}
      <Card className="border-yellow-500/30 bg-yellow-900/5">
        <h3 className="text-xl font-bold text-yellow-400 mb-5 flex items-center gap-2">
          🕐 Live 100+ Years — Longevity Protocol
        </h3>
        <div className="grid gap-4">
          {longevityProtocol.map((item) => (
            <div key={item.habit} className="flex items-start gap-4 bg-gray-700/30 rounded-xl p-4">
              <span className="text-3xl flex-shrink-0">{item.icon}</span>
              <div>
                <div className="text-white font-bold text-sm mb-1">{item.habit}</div>
                <div className="text-gray-400 text-sm">{item.impact}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-yellow-900/20 border border-yellow-700/30 rounded-xl p-4">
          <p className="text-yellow-300 text-sm">
            <strong>🔬 Harvard 85-Year Longevity Study found:</strong> The people who live longest and happiest share these traits: (1) Regular exercise, (2) Healthy diet, (3) Strong social relationships, (4) Sense of purpose, (5) Low chronic stress. You are working on ALL of these right now.
          </p>
        </div>
      </Card>
    </div>
  );
}
